module DWT_Haar #(
    parameter DATA_WIDTH         = 14,
    parameter TAPS               = 4,
    parameter LINE_WIDTH         = 12,
    parameter DEFECT_ADDRA_WIDTH = 32,
    parameter COORD_WIDTH        = 24,
    parameter COUNT_PORT_SIZE    = 10,
    parameter PIX_WIDTH          = 12,
    parameter DELAY_WIDTH        = 12,
    parameter DEFECT_NUM_WIDTH   = 10
) (
    input                            clk,
    input                            sensor_clk_x4,
    input                            rd_clk,
    input                            reset,
    input                            newframe,
    input      [     LINE_WIDTH-1:0] LINE,           //行数
    input      [      PIX_WIDTH-1:0] PIX,            //每行的像素数
    input      [                8:0] LINE_S,         //从第几行开始														
    input      [                9:0] PIX_S,          //从一行的第几个像素开始
    input                            compress_data_test,
    input      [DATA_WIDTH*TAPS-1:0] data_in,
    input                            data_in_valid,
    output     reg  [DATA_WIDTH*TAPS-1:0]     data_out,       //  rgb data
    output     reg                            data_out_valid,

    output     reg  [63:0]                    data_out_64bit,       //  rgb data
    output     reg                            data_out_64bit_fv, 
    output     reg                            data_out_64bit_valid   

);
//wire
  wire line1_buf_valid;
  wire line2_buf_valid;
  wire line3_buf_valid;
  wire line4_buf_valid;

  wire [DATA_WIDTH*TAPS-1:0]      line0_buf;
  wire [DATA_WIDTH*TAPS-1:0]      line1_buf;
  reg [DATA_WIDTH*TAPS-1:0]      line0_buf_0 ;
  reg [DATA_WIDTH*TAPS-1:0]      line1_buf_0 ;
  wire [DATA_WIDTH*TAPS-1:0]      line4_buf ;

//reg
  reg [15:0] LINE_reg_0;
  reg [15:0] LINE_reg_1;
  reg [15:0] PIX_reg_0;
  reg [15:0] PIX_reg_1;
  reg [15:0] LINE_S_reg_0;
  reg [15:0] LINE_S_reg_1;
  reg [15:0] PIX_S_reg_0;
  reg [15:0] PIX_S_reg_1;
  reg        newframe_0;

  reg        data_in_valid0;
  reg        data_in_valid1;
  reg        data_in_valid2;
  reg        data_in_valid3;

  reg        line1_buf_valid0;
  reg        line1_buf_valid1;
  reg        line1_buf_valid2;
  reg        line1_buf_valid3;
  reg        line1_buf_valid4;
  reg        line1_buf_valid5;

  reg        line1_buf_valid0_even;
  reg        line1_buf_valid1_even;
  reg        line1_buf_valid2_even;
  reg        line1_buf_valid3_even;
  reg        line1_buf_valid4_even;
  reg        line1_buf_valid5_even;

	reg [11:0] pix_cnt;
	reg [11:0] line_cnt;

  reg [DATA_WIDTH + 1     : 0]      data_add;     // 2*2 数据矩阵相加
  reg [DATA_WIDTH - 1     : 0]      data_A;       //  近似分量
  reg [DATA_WIDTH - 1     : 0]      data_H;       //  水平细节分量
  reg [DATA_WIDTH - 1     : 0]      data_V;       //  垂直细节分量
  reg [DATA_WIDTH - 1     : 0]      data_D;       //  对角线细节分量

  // reg [DATA_WIDTH + 1     : 0]      data_add_0;     // 2*2 数据矩阵相加
  // reg [DATA_WIDTH - 1     : 0]      data_A_0;       //  近似分量
  // reg [DATA_WIDTH - 1     : 0]      data_H_0;       //  水平细节分量
  // reg [DATA_WIDTH - 1     : 0]      data_V_0;       //  垂直细节分量
  // reg [DATA_WIDTH - 1     : 0]      data_D_0;       //  对角线细节分量

  // reg [DATA_WIDTH + 1     : 0]      data_add_1;
  // reg [DATA_WIDTH - 1     : 0]      data_A_1;  
  // reg [DATA_WIDTH - 1     : 0]      data_H_1;  
  // reg [DATA_WIDTH - 1     : 0]      data_V_1;  
  // reg [DATA_WIDTH - 1     : 0]      data_D_1;  
  always @(posedge clk) begin
    LINE_reg_0   <=  LINE;
    LINE_reg_1   <=  LINE_reg_0;
    PIX_reg_0    <=  PIX;
    PIX_reg_1    <=  PIX_reg_0;
    LINE_S_reg_0 <=  LINE_S;
    LINE_S_reg_1 <=  LINE_S_reg_0;
    PIX_S_reg_0  <=  PIX_S;
    PIX_S_reg_1  <=  PIX_S_reg_0;
    newframe_0   <=  newframe;

    data_in_valid0 <= data_in_valid;
    data_in_valid1 <= data_in_valid0;
    data_in_valid2 <= data_in_valid1;
    data_in_valid3 <= data_in_valid2;

		line1_buf_valid0	<= line1_buf_valid;
		line1_buf_valid1	<= line1_buf_valid0;
    line1_buf_valid2	<= line1_buf_valid1;
    line1_buf_valid3  <= line1_buf_valid2;
    line1_buf_valid4  <= line1_buf_valid3;
    line1_buf_valid5  <= line1_buf_valid4;

    line1_buf_valid0_even <= line1_buf_valid_even;
    line1_buf_valid1_even <= line1_buf_valid0_even;
    line1_buf_valid2_even <= line1_buf_valid1_even;
    line1_buf_valid3_even <= line1_buf_valid2_even;
    line1_buf_valid4_even <= line1_buf_valid3_even;
    line1_buf_valid5_even <= line1_buf_valid4_even;
  end
/******************记录行和列*********************/
always@(posedge clk)
	begin
	  if(reset) begin
	  	pix_cnt<=12'd0;
	  end
	  else if(line1_buf_valid) begin
	    pix_cnt<=pix_cnt+12'd1;
	  end
	  else begin
	    pix_cnt<=12'd0;
	  end 
	end

  always@(posedge clk)
  begin
    if(reset|| newframe_0) begin
    	line_cnt<=12'd0;
    end
    else if(line1_buf_valid0 && !line1_buf_valid) begin
      line_cnt<= line_cnt+12'd1;
    end
    else begin
      line_cnt<= line_cnt ;
    end
  end
/**************缓存一行*****************/
  two_line_bufs #(
      .DW           (DATA_WIDTH * TAPS),
      .LW           (LINE_WIDTH),
      .DEPTH        (COUNT_PORT_SIZE),
      .DEVICE_FAMILY("Xilinx")
  ) data_buf_1 (
      .clk           (clk),
      .rst           (reset),
      .v_sync        (newframe_0),
      .v_size        (LINE_reg_1),
      .data_in       (data_in),
      .data_in_valid (data_in_valid),
      .line_buf_out1 (line0_buf),      //output   当前行的数据  data_in
      .line_buf_out2 (line1_buf),      //output   上一行的数据
      .line_buf_valid(line1_buf_valid)  //output
  );
wire line1_buf_valid_even;
assign line1_buf_valid_even =  (!line_cnt[0]) ? line1_buf_valid : 1'b0;     

  // assign data_out	= data_in;
  // always@(posedge clk)
  // begin
  //   data_out_valid <= data_in_valid ;
  // end

reg [DATA_WIDTH*TAPS-1:0]      line0_buf_dly;
reg [DATA_WIDTH*TAPS-1:0]      line1_buf_dly;
  always@(posedge clk) begin
    line0_buf_dly <= line0_buf ;
    line1_buf_dly <= line1_buf ;
  end
reg [DATA_WIDTH*TAPS : 0] H_0;
reg [DATA_WIDTH*TAPS : 0] H_1;
reg [DATA_WIDTH*TAPS : 0] V_0;
reg [DATA_WIDTH*TAPS : 0] V_1;
reg [DATA_WIDTH*TAPS : 0] D_0;
reg [DATA_WIDTH*TAPS : 0] D_1;

  always@(posedge clk) begin
    if(reset|| newframe_0) begin
    	H_0  <=  9'd0;
      H_1  <=  9'd0;  
      V_0  <=  9'd0;  
      V_1  <=  9'd0;  
      D_0  <=  9'd0;  
      D_1  <=  9'd0;  
    end
   else if(line1_buf_valid_even || line1_buf_valid0_even)begin
      if(matrix_flag)begin
      H_0  <=  line0_buf      +  line0_buf_dly  ;
      H_1  <=  line1_buf      +  line1_buf_dly  ;
      V_0  <=  line0_buf      +  line1_buf      ;
      V_1  <=  line0_buf_dly  +  line1_buf_dly  ;
      D_0  <=  line1_buf      +  line0_buf_dly  ;
      D_1  <=  line1_buf_dly  +  line0_buf      ;
      end
    else begin
      H_0  <=  H_0 ;
      H_1  <=  H_1 ;
      V_0  <=  V_0 ;
      V_1  <=  V_1 ;
      D_0  <=  D_0 ;
      D_1  <=  D_1 ;    
    end
   end
   else begin
      H_0  <=  9'd0;
      H_1  <=  9'd0;  
      V_0  <=  9'd0;  
      V_1  <=  9'd0;  
      D_0  <=  9'd0;  
      D_1  <=  9'd0;  
   end
  end

reg [DATA_WIDTH*TAPS-1 : 0] H_positive;
reg [DATA_WIDTH*TAPS-1 : 0] H_negative;
reg [DATA_WIDTH*TAPS-1 : 0] V_positive;
reg [DATA_WIDTH*TAPS-1 : 0] V_negative;
reg [DATA_WIDTH*TAPS-1 : 0] D_positive;
reg [DATA_WIDTH*TAPS-1 : 0] D_negative;
  always@(posedge clk) begin
  H_positive <= (H_0 - H_1) >> 1 ; 
  H_negative <= (H_1 - H_0) >> 1 ;
  V_positive <= (V_0 - V_1) >> 1 ;
  V_negative <= (V_1 - V_0) >> 1 ;
  D_positive <= (D_0 - D_1) >> 1 ;
  D_negative <= (D_1 - D_0) >> 1 ;
  end

reg H_flag;
reg V_flag;
reg D_flag;
  always@(posedge clk) begin
    if(reset|| newframe_0)
    	H_flag <= 1'd0;
    else if(H_0 >= H_1)
    	H_flag <= 1'd1;      
    else
     	H_flag <= 1'd0;     
  end
  always@(posedge clk) begin
    if(reset|| newframe_0)
    	V_flag <= 1'd0;
    else if(V_0 >= V_1)
    	V_flag <= 1'd1;      
    else
     	V_flag <= 1'd0;     
  end
    always@(posedge clk) begin
    if(reset|| newframe_0)
    	D_flag <= 1'd0;
    else if(D_0 >= D_1)
    	D_flag <= 1'd1;      
    else
     	D_flag <= 1'd0;     
  end
/**************低频计算*****************/
  always@(posedge clk) begin
    if(reset|| newframe_0) begin
    	data_add<=   10'd0;
      data_A  <=   8'd0; 
    end
    else if(line1_buf_valid_even || line1_buf_valid1_even)begin   //line1_buf_valid2_even  是data_A有效指示信号
     	data_add <=   line0_buf +  line0_buf_dly + line1_buf + line1_buf_dly;
      data_A   <=   AHVD_flag ? data_add[9:2] : data_A;   
    end
    else begin
      data_add <=   10'd0;//data_add;
      data_A   <=   8'd0; //data_A  ;  
    end
  end
/**************高频计算*****************/
  always@(posedge clk) begin
    if(reset|| newframe_0) begin
      data_H  <=   8'd0;  
      data_V  <=   8'd0;  
      data_D  <=   8'd0;  
    end
    else if(line1_buf_valid2_even)begin
      data_H  <=   H_flag ?  H_positive : H_negative;      
      data_V  <=   V_flag ?  V_positive : V_negative;      
      data_D  <=   D_flag ?  D_positive : D_negative;    
    end
    else begin
      data_H   <=   8'd0; //data_H  ;  
      data_V   <=   8'd0; //data_V  ;  
      data_D   <=   8'd0; //data_D  ; 
    end
  end
reg matrix_flag;
  always@(posedge clk) begin
    if(reset|| newframe_0) 
      matrix_flag <= 1'b0;
    else if(line1_buf_valid_even)
      matrix_flag <= ~matrix_flag;    
    else
      matrix_flag <= 1'b0;
    end
reg AHVD_flag;
reg matrix_flag_0;
reg matrix_flag_1;
reg matrix_flag_2;
reg matrix_flag_3;
reg matrix_flag_4;
  always@(posedge clk) begin
      AHVD_flag <= matrix_flag;  
      matrix_flag_0 <=   matrix_flag;
      matrix_flag_1 <=   matrix_flag_0;
      matrix_flag_2 <=   matrix_flag_1;
      matrix_flag_3 <=   matrix_flag_2;
      matrix_flag_4 <=   matrix_flag_3;

    end
/***************** 8bit低频相邻像素差值压缩************************/
localparam THRESHOLD = 8 ;
reg  reference_flag;                      //基准像素指示信号
reg  [DATA_WIDTH - 1 :0] Reference_pixel; //基准像素指示信号
reg  [DATA_WIDTH - 1 : 0]  deviation;     //相邻像素差值
reg                        negative_flag; //相邻差值为负数的指示信号   拉高时是负数
reg  [11 : 0]              deviation_cnt; //统计符合差值范围的数据块中的数据一共有多少个
reg  [11 : 0]              deviation_cnt_reg;
reg  deviation_cnt_reg_en;  
reg  [11 : 0] deviation_cg_wr_addr; 
reg  [11 : 0] deviation_cg_wr_addr_reg;  
reg  deviation_wr_en; 
reg  [DATA_WIDTH - 1 : 0]  data_A_0;
reg  [DATA_WIDTH - 1 : 0]  data_A_1;
reg  [DATA_WIDTH - 1 : 0]  data_A_2;
reg  [DATA_WIDTH - 1 : 0]  data_A_3;
  always@(posedge clk)begin
    if(reset|| newframe_0)begin
      data_A_0  <= 8'd0;
      data_A_1  <= 8'd0;
      data_A_2  <= 8'd0;
      data_A_3  <= 8'd0;
    end
    else begin
      data_A_0  <= data_A;
      data_A_1  <= data_A_0;
      data_A_2  <= data_A_1;
      data_A_3  <= data_A_2;
    end
  end

  always@(posedge clk)begin
    if(reset|| newframe_0)
      Reference_pixel <= 8'd0;
    else if(!line1_buf_valid4_even && line1_buf_valid3_even)    //第一行的第一个数据
      Reference_pixel <= data_A_0;
    else if(line1_buf_valid4_even && line1_buf_valid3_even)begin
      if ((deviation < THRESHOLD) && (matrix_flag_4))
        Reference_pixel <= Reference_pixel;
      else if((deviation >= THRESHOLD)  && (matrix_flag_4))
        Reference_pixel <= data_A;     
      else
        Reference_pixel <= Reference_pixel;   
    end
    else
      Reference_pixel <= Reference_pixel;          
  end

  always@(posedge clk)begin
    if(reset|| newframe_0)begin
      deviation <= 4'd0;  
      negative_flag <= 1'd0;
    end
    else if(line1_buf_valid2_even || line1_buf_valid4_even)begin
      if( matrix_flag_1 )begin
        deviation <= (data_A_0 > data_A) ? (data_A_0 - data_A) : (data_A - data_A_0);    
        negative_flag <= (data_A_0 > data_A) ? 1'b1 : 1'b0;   //拉高一个时钟周期
      end
      else begin
        deviation <= deviation;
        negative_flag <= negative_flag;    
      end
    end
    else begin
      deviation <= 4'd0;    
      negative_flag <= 1'd0; 
    end
  end

  always@(posedge clk)begin
    if(reset|| newframe_0)begin
      reference_flag <= 1'b0;    
      deviation_cnt  <= 12'd0;
      deviation_cnt_reg    <= 12'd0;
      deviation_cnt_reg_en <= 1'b0;
      deviation_cg_wr_addr <= 12'd0;
      deviation_cg_wr_addr_reg <= 12'd0;
    end
    else if(!line1_buf_valid4_even && line1_buf_valid3_even)begin   //第一个像素
        reference_flag <= 1'b1;
        deviation_cnt  <= 12'd0;
        deviation_cnt_reg    <= 12'd0;
        deviation_cnt_reg_en <= 1'b0; 
        deviation_cg_wr_addr <= 12'd0;
        deviation_cg_wr_addr_reg <= deviation_cg_wr_addr_reg;
    end    
    else if(line1_buf_valid4_even && line1_buf_valid3_even)begin
      if ((deviation < THRESHOLD) && (matrix_flag_4))begin
        reference_flag <= 1'b0; 
        deviation_cnt  <= deviation_cnt + 1'b1; 
        deviation_cnt_reg    <= 12'd0;
        deviation_cnt_reg_en <= 1'b0; 
        deviation_cg_wr_addr <= deviation_cg_wr_addr;
        deviation_cg_wr_addr_reg <= deviation_cg_wr_addr_reg;
      end
      else if((deviation >= THRESHOLD)  && (matrix_flag_4))begin
        reference_flag <= 1'b1; 
        deviation_cnt  <= 12'd0; 
        deviation_cnt_reg    <= deviation_cnt;
        deviation_cnt_reg_en <= 1'b1;
        deviation_cg_wr_addr <= deviation_cg_wr_addr + 1'b1;
        deviation_cg_wr_addr_reg <= deviation_cg_wr_addr_reg;    
      end
      else begin
        reference_flag <= 1'b0;    
        deviation_cnt  <= deviation_cnt;
        deviation_cnt_reg    <= 12'd0;
        deviation_cnt_reg_en <= 1'b0;
        deviation_cg_wr_addr <= deviation_cg_wr_addr;
        deviation_cg_wr_addr_reg <= deviation_cg_wr_addr_reg;  
      end   
    end
    else if(line1_buf_valid4_even && !line1_buf_valid3_even)begin
        if(deviation >= THRESHOLD )begin
            deviation_cg_wr_addr <= deviation_cg_wr_addr + 1'b1;
            deviation_cnt_reg_en <= 1'b1;
            deviation_cnt_reg    <= deviation_cnt;
            deviation_cg_wr_addr_reg <= deviation_cg_wr_addr_reg;             
        end
        else begin
            deviation_cg_wr_addr <= deviation_cg_wr_addr + 1'b1;
            deviation_cnt_reg_en <= 1'b1;
            deviation_cnt_reg    <= deviation_cnt;
            deviation_cg_wr_addr_reg <= deviation_cg_wr_addr_reg;             
        end
    end
    else if(line1_buf_valid5_even && !line1_buf_valid4_even)begin
            deviation_cg_wr_addr <= 12'd0;
            deviation_cnt_reg_en <= 1'b0;
            deviation_cg_wr_addr_reg <= deviation_cg_wr_addr;  
    end
    else begin
      reference_flag <= 1'b0;    
      deviation_cnt  <= 12'd0;
      deviation_cnt_reg    <= 12'd0;
      deviation_cnt_reg_en <= 1'b0; 
      deviation_cg_wr_addr <= 12'd0;
      deviation_cg_wr_addr_reg <= deviation_cg_wr_addr_reg; 
    end       
  end

  always@(posedge clk)begin
    if(reset|| newframe_0)
        deviation_wr_en <= 1'b0;
    else if(line1_buf_valid4_even)begin
      if((matrix_flag_2 && matrix_flag_4) && (deviation < THRESHOLD))
          deviation_wr_en <= 1'b1;
      else
          deviation_wr_en <= 1'b0;
    end
    else
        deviation_wr_en <= 1'b0;
  end

wire  [7 : 0]   data_out_A;
wire            data_out_valid_A;
wire            fifo_insert_done_A;

  compress_low_frequency#(
      .DATA_WIDTH   (DATA_WIDTH),//      = 14,
      .LINE_WIDTH   (LINE_WIDTH),//      = 12,
      .PIX_WIDTH    (PIX_WIDTH),//      = 12,
      .TAPS         (TAPS)//      = 4
  )compress_low_frequency(
      .clk                  (clk),                      //input                               
      .sensor_clk_x4        (sensor_clk_x4),//(clk),            //input                                
      .LINE                 (LINE) ,   //行数             //input       [LINE_WIDTH-1:0]             
      .PIX                  (PIX) ,    //每行的像素数         //input       [PIX_WIDTH-1:0]               
      .reset                (reset),                    //input                                  
      .newframe             (newframe),                 //input   
      .line1_buf_valid5_even(line1_buf_valid5_even),                                       
      .data_dvalid_A        (line1_buf_valid2_even),            //input        [7 : 0]                       
      .data_A               (data_A),                   //input                                  
      .deviation_cg_wr_addr_reg (deviation_cg_wr_addr_reg), //input        [11 : 0]                  
      .reference_flag           (reference_flag),           //input                                  
      .Reference_pixel          (Reference_pixel),          //input        [7 : 0]                   
      .deviation_cnt_reg_en     (deviation_cnt_reg_en),     //input                                    
      .deviation_cnt_reg        (deviation_cnt_reg),        //input        [11 : 0]  
      .negative_flag            (negative_flag),                
      .deviation                (deviation),                //input        [7 : 0]                   
      .deviation_wr_en          (deviation_wr_en),
      .deviation_dvalid         (matrix_flag_2),        //input     
      .fifo_insert_done_all     (fifo_insert_done_all),    
      .frequency_rd_flag        (frequency_rd_flag[0]),                                     


      .fifo_insert_done       (fifo_insert_done_A),
      .data_out               (data_out_A), //output  reg [7:0]   
      .data_lv                (data_out_valid_A)   //output  reg         

  );

/************** 高频bit范围判断***************/
 reg [1:0] bit_flag_H;
 reg [1:0] bit_flag_V;
 reg [1:0] bit_flag_D;
  always@(posedge clk)begin
    if(reset|| newframe_0)
      bit_flag_H <= 2'd0;
    else if(line1_buf_valid3_even)begin//else if(matrix_flag_2)begin
      if(data_H < 8'd2)                                 //2bit   -1  0  1
        bit_flag_H <= 2'd0; 
      else if((data_H < 8'd10) && (data_H >= 8'd2))    //4bit
        bit_flag_H <= 2'd1;
      else if((data_H < 8'd42) && (data_H >= 8'd10))   //6bit
        bit_flag_H <= 2'd2;
      else if((data_H < 8'd225) && (data_H >= 8'd42)) //8bit
        bit_flag_H <= 2'd3;    
      else
        bit_flag_H <= bit_flag_H;         
    end 
    else
      bit_flag_H <= bit_flag_H;    
  end

  always@(posedge clk)begin
    if(reset|| newframe_0)
      bit_flag_V <= 2'd0;
    else if(line1_buf_valid3_even)begin//else if(matrix_flag_2)begin
      if(data_V < 8'd2)
        bit_flag_V <= 2'd0; 
      else if((data_V < 8'd10) && (data_V >= 8'd2))
        bit_flag_V <= 2'd1;
      else if((data_V < 8'd42) && (data_V >= 8'd10))
        bit_flag_V <= 2'd2;
      else if((data_V < 8'd225) && (data_V >= 8'd42))
        bit_flag_V <= 2'd3;    
      else
        bit_flag_V <= bit_flag_V;              
    end 
    else
      bit_flag_V <= bit_flag_V;    
  end

  always@(posedge clk)begin
    if(reset|| newframe_0)
      bit_flag_D <= 2'd0;
    else if(line1_buf_valid3_even)begin//else if(matrix_flag_2)begin
      if(data_D < 8'd2)
        bit_flag_D <= 2'd0; 
      else if((data_D < 8'd10) && (data_D >= 8'd2))
        bit_flag_D <= 2'd1;
      else if((data_D < 8'd42) && (data_D >= 8'd10))
        bit_flag_D <= 2'd2;
      else if((data_D < 8'd225) && (data_D >= 8'd42))
        bit_flag_D <= 2'd3;
      else
        bit_flag_D <= bit_flag_D;        
    end 
    else
      bit_flag_D <= bit_flag_D;    
  end


 reg [DATA_WIDTH - 1     : 0] data_H_dly;
 reg [DATA_WIDTH - 1     : 0] data_V_dly;
 reg [DATA_WIDTH - 1     : 0] data_D_dly;
 reg [1:0] H_flag_dly;
 reg [1:0] V_flag_dly;
 reg [1:0] D_flag_dly;
  always@(posedge clk)begin
   if(reset|| newframe_0)begin
      data_H_dly <= 2'd0;
      data_V_dly <= 2'd0;
      data_D_dly <= 2'd0;
      H_flag_dly <= 1'd0;
      V_flag_dly <= 1'd0;
      D_flag_dly <= 1'd0;
     end
   else begin
      data_H_dly <= data_H;
      data_V_dly <= data_V;
      data_D_dly <= data_D;
      H_flag_dly <= {H_flag_dly[0],H_flag};
      V_flag_dly <= {V_flag_dly[0],V_flag};
      D_flag_dly <= {D_flag_dly[0],D_flag};
   end
  end
// /*****************H域 compress *********************/
wire  [7 : 0]   data_out_H;
wire            data_out_valid_H;
wire            fifo_insert_done_H;
bit_block#(
    .DATA_WIDTH(DATA_WIDTH),
    .TAPS(TAPS)
)bit_block_H(
    .clk             (clk),               //input                            clk,
    .sensor_clk_x4   (sensor_clk_x4),     //input                            sensor_clk_x4,
    .reset           (reset),             //input                            reset,
    .newframe        (newframe),          //input                            newframe,
    .bit_flag        (bit_flag_H),        //高频数据幅度范围
    .negative_sign   (H_flag_dly[1:1]),        //高频数值正负指示信号
    .data            (data_H_dly),        //高频数据幅度
    .pix_vaild       (matrix_flag_3),
    .data_valid      (line1_buf_valid4_even),  //input                            data_valid,
    .fifo_insert_done_all(fifo_insert_done_all), 
    .frequency_rd_flag  (frequency_rd_flag[1]),

    .fifo_insert_done(fifo_insert_done_H),
    .data_out        (data_out_H),                  //output  [DATA_WIDTH*TAPS - 1 :0] data_out,       //  rgb data
    .data_out_valid  (data_out_valid_H)                   //output     reg                   data_out_valid
);

// /*****************V域 compress *********************/
wire  [7 : 0]   data_out_V;
wire            data_out_valid_V;
wire            fifo_insert_done_V;
bit_block#(
    .DATA_WIDTH(DATA_WIDTH),
    .TAPS(TAPS)
)bit_block_V(
    .clk             (clk),               //input                            clk,
    .sensor_clk_x4   (sensor_clk_x4),     //input                            sensor_clk_x4,
    .reset           (reset),             //input                            reset,
    .newframe        (newframe),          //input                            newframe,
    .bit_flag        (bit_flag_V),        //input      [ 2 :0]               bit_flag,
    .negative_sign   (V_flag_dly[1:1]),        //高频数值正负指示信号
    .data            (data_V_dly),        //input   [DATA_WIDTH*TAPS - 1 :0] data,
    .pix_vaild       (matrix_flag_3),
    .data_valid      (line1_buf_valid4_even),  //input                            data_valid,
    .fifo_insert_done_all(fifo_insert_done_all),  
    .frequency_rd_flag  (frequency_rd_flag[2]),

    .fifo_insert_done(fifo_insert_done_V),
    .data_out        (data_out_V),                  //output  [DATA_WIDTH*TAPS - 1 :0] data_out,       //  rgb data
    .data_out_valid  (data_out_valid_V)                   //output     reg                   data_out_valid
);

// /*****************D域 compress *********************/
wire  [7 : 0]   data_out_D;
wire            data_out_valid_D;
wire            fifo_insert_done_D;
bit_block#(
    .DATA_WIDTH(DATA_WIDTH),
    .TAPS(TAPS)
)bit_block_D(
    .clk             (clk),               //input                            clk,
    .sensor_clk_x4   (sensor_clk_x4),     //input                            sensor_clk_x4,
    .reset           (reset),             //input                            reset,
    .newframe        (newframe),          //input                            newframe,
    .bit_flag        (bit_flag_D),        //input      [ 2 :0]               bit_flag,
    .negative_sign   (D_flag_dly[1:1]),        //高频数值正负指示信号
    .data            (data_D_dly),        //input   [DATA_WIDTH*TAPS - 1 :0] data,
    .pix_vaild       (matrix_flag_3),
    .data_valid      (line1_buf_valid4_even),  //input                            data_valid,
    .fifo_insert_done_all(fifo_insert_done_all),  
    .frequency_rd_flag  (frequency_rd_flag[3]),

    .fifo_insert_done(fifo_insert_done_D),
    .data_out        (data_out_D),                  //output  [DATA_WIDTH*TAPS - 1 :0] data_out,       //  rgb data
    .data_out_valid  (data_out_valid_D)                   //output     reg                   data_out_valid
);

reg  data_out_valid_A_d;
reg  data_out_valid_H_d;
reg  data_out_valid_V_d;
reg  data_out_valid_D_d;
  always@(posedge sensor_clk_x4)begin
      data_out_valid_A_d <= data_out_valid_A;
      data_out_valid_H_d <= data_out_valid_H;
      data_out_valid_V_d <= data_out_valid_V;
      data_out_valid_D_d <= data_out_valid_D;
  end  
reg       fifo_insert_done_all;
reg [3:0] frequency_rd_flag;      //决定读取那个频域以及何时读取压缩好的数据
  always@(posedge sensor_clk_x4)begin
    if(reset|| newframe_0)begin
      fifo_insert_done_all <= 1'd0;
      frequency_rd_flag       <= 4'd0;
    end
    else if(fifo_insert_done_A && fifo_insert_done_H && fifo_insert_done_V && fifo_insert_done_D)begin
      fifo_insert_done_all <= 1'b1;
      frequency_rd_flag       <= 4'b0001;     //开始读A域的压缩数据    
    end
    else if(data_out_valid_A_d && !data_out_valid_A && fifo_insert_done_all)begin
      fifo_insert_done_all <= 1'b1;
      frequency_rd_flag <= 4'b0010;              //当读A域的压缩数据结束之后开始读H域的压缩数据
    end   
    else if(data_out_valid_H_d && !data_out_valid_H && fifo_insert_done_all)begin
      fifo_insert_done_all <= 1'b1;
      frequency_rd_flag <= 4'b0100;              //当读H域的压缩数据结束之后开始读V域的压缩数据
    end   
    else if(data_out_valid_V_d && !data_out_valid_V && fifo_insert_done_all)begin
      fifo_insert_done_all <= 1'b1;
      frequency_rd_flag <= 4'b1000;              //当读V域的压缩数据结束之后开始读D域的压缩数据
    end   
    else if(data_out_valid_D_d && !data_out_valid_D && fifo_insert_done_all)begin
      fifo_insert_done_all <= 1'b0;
      frequency_rd_flag <= 4'b0000;              //H/V/D域的数据都读取完成
    end   
    else begin
      fifo_insert_done_all <= fifo_insert_done_all;
      frequency_rd_flag <= frequency_rd_flag;       
    end  
  end  

  always@(posedge sensor_clk_x4)begin
    if(data_out_valid_A)begin      //当读取H域的压缩数据时，模块输出H域的压缩数据
      data_out	     <= data_out_A;
      data_out_valid <= data_out_valid_A ;
    end
    else if(data_out_valid_H)begin      //当读取V域的压缩数据时，模块输出V域的压缩数据
      data_out	     <= data_out_H;   
      data_out_valid <= data_out_valid_H;
    end
    else if(data_out_valid_V)begin      //当读取V域的压缩数据时，模块输出V域的压缩数据
      data_out	     <= data_out_V;   
      data_out_valid <= data_out_valid_V;
    end
    else if(data_out_valid_D)begin      //当读取D域的压缩数据时，模块输出D域的压缩数据
      data_out	     <= data_out_D;   
      data_out_valid <= data_out_valid_D;
    end
    else  begin
      data_out	     <= 8'd0;
      data_out_valid <= 1'b0;
    end
  end


reg         empty;
reg  [31:0] data_64bit;
reg         data_64bit_rd;     

//**************** 最终总和各个频域的压缩数据，输出64bit的数据 *******************//
ultimately_compressing_data ultimately_compressing_data(
    // Inputs
    .DATA     (data_out),    //[7:0]
    .RCLOCK   (rd_clk),
    .RE       (data_64bit_rd),
    .RRESET_N (!newframe),
    .WCLOCK   (sensor_clk_x4),
    .WE       (data_out_valid || data_out_valid_wr_monitor),
    .WRESET_N (!newframe),
    // Outputs
    .EMPTY    (empty),
    .FULL     (),
    .Q        (data_64bit),//[63:0]
    .RDCNT    () //[9:0]
);

reg  data_out_valid_wr_monitor;   
reg  [3:0] monitor_cnt;
reg  [3:0] wr_en_cnt;
reg  line1_buf_valid5_even_d0_x4;
reg  line1_buf_valid5_even_d1_x4;
reg  data_64bit_rd_d0_x4;
// ******************* 解决以8bit写入fifo，以64bit读出，写入的bit数不是64bit的倍数
always@(posedge sensor_clk_x4)begin
    line1_buf_valid5_even_d0_x4 <= line1_buf_valid5_even;
    line1_buf_valid5_even_d1_x4 <= line1_buf_valid5_even_d0_x4;
    data_64bit_rd_d0_x4         <= data_64bit_rd;
end
always@(posedge sensor_clk_x4)begin
    if(reset || newframe)
        monitor_cnt        <= 4'd4;
    else if(line1_buf_valid5_even_d1_x4 && !line1_buf_valid5_even_d0_x4)
        monitor_cnt        <= 4'd4;
    else if(data_out_valid)begin
        if(monitor_cnt == 4'd0)
            monitor_cnt <= 4'd3;
        else
            monitor_cnt <= monitor_cnt - 4'd1;
    end
    else
        monitor_cnt  <= monitor_cnt;
end

always@(posedge sensor_clk_x4)begin
    if(reset || newframe)begin
        data_out_valid_wr_monitor  <= 4'd0;
        wr_en_cnt                <= 4'd0;
    end
    else if(line1_buf_valid5_even_d1_x4 && !line1_buf_valid5_even_d0_x4)begin
        data_out_valid_wr_monitor  <= 4'd0; 
        wr_en_cnt                <= 4'd0;   
    end
    else if(data_64bit_rd_d0_x4)begin   
        if(monitor_cnt == wr_en_cnt)begin
            data_out_valid_wr_monitor  <= 4'd0;    
            wr_en_cnt                  <= wr_en_cnt;     
        end
        else begin
            data_out_valid_wr_monitor  <= 4'd1;    
            wr_en_cnt                <= wr_en_cnt + 4'd1;   
        end
    end
    else begin
        data_out_valid_wr_monitor  <= data_out_valid_wr_monitor; 
        wr_en_cnt                <= wr_en_cnt         ;      
    end
end

  always@(posedge rd_clk)begin
    if(reset|| newframe_0)
      data_64bit_rd <= 1'b0;
    else if(frequency_rd_flag_d0[3] && !frequency_rd_flag_d[3])   //当D域的压缩数据读取完成之后，开始读取一行总的压缩数据
      data_64bit_rd <= 1'b1;
    else if(empty)
      data_64bit_rd <= 1'b0;
    else
      data_64bit_rd <= data_64bit_rd;
  end

reg  [3:0] frequency_rd_flag_d;
reg  [3:0] frequency_rd_flag_d0;
reg  [3:0] monitor_cnt_rd_clk;
reg  empty_rd_clk;
reg line1_buf_valid5_even_d0;
reg data_64bit_rd_d0;
reg data_64bit_rd_d1;
  always@(posedge rd_clk)begin
      empty_rd_clk         <= empty;
      monitor_cnt_rd_clk   <= monitor_cnt;
      frequency_rd_flag_d  <= frequency_rd_flag;
      frequency_rd_flag_d0 <= frequency_rd_flag_d;
      line1_buf_valid5_even_d0 <= line1_buf_valid5_even;
      data_64bit_rd_d0 <= data_64bit_rd;
      data_64bit_rd_d1 <= data_64bit_rd_d0;
      //************** 最终的64bit数据输出
      data_out_64bit           <= {data_64bit[7:0],8'd0,data_64bit[15:8],8'd0,data_64bit[23:16],8'd0,data_64bit[31:24],8'd0};//{data_64bit[31:24],8'd0,data_64bit[23:16],8'd0,data_64bit[15:8],8'd0,data_64bit[7:0],8'd0};
      data_out_64bit_valid     <= ((data_64bit_rd_d0 && data_64bit_rd_d1) || kkj_lv);
  end

//************** 最终的64bit数据fv指示信号判定
reg [9:0] data_out_64bit_valid_cnt;
  always@(posedge rd_clk)begin
    if(reset|| newframe_0)
      data_out_64bit_valid_cnt <= 10'd0;
    else if(!data_64bit_rd_d0 && data_64bit_rd_d1)    //对 data_out_64bit_valid_cnt 进行计数
      data_out_64bit_valid_cnt <= data_out_64bit_valid_cnt + 10'd1;
    else
      data_out_64bit_valid_cnt <= data_out_64bit_valid_cnt;
  end

  always@(posedge rd_clk)begin
    if(reset|| newframe_0)
      data_out_64bit_fv <= 1'b0;
    else if(data_64bit_rd && !data_64bit_rd_d0)   //在 newframe_0 之后，第一个 data_64bit_rd 拉高之后，data_out_64bit_fv 拉高
      data_out_64bit_fv <= 1'b1;
    else if(data_out_64bit_valid_cnt == LINE[12:1])   //在 data_out_64bit_valid_cnt 为原始行数的一半时，即压缩完成之后 data_out_64bit_fv 拉低
      data_out_64bit_fv <= 1'b0;
    else
      data_out_64bit_fv <= data_out_64bit_fv;
  end

  reg [10:0]  kkj_cnt;
  reg         kkj_lv;
  wire [15:0] PIX_NUM;

  assign PIX_NUM = PIX[11:3];

  always @(posedge rd_clk) begin
    if (data_out_64bit_fv) begin
      kkj_cnt <= 1'b0;
    end else if (kkj_cnt == PIX_NUM * 3 + 160) begin
      kkj_cnt <= kkj_cnt;
    end else begin
      kkj_cnt <= kkj_cnt + 1'b1;
    end
  end

  always @(posedge rd_clk) begin
    if (data_out_64bit_fv) begin
      kkj_lv <= 1'b0;
    end else if (kkj_cnt >= 64 && kkj_cnt <= PIX_NUM + 63) begin
      kkj_lv <= 1'b1;
    end else if (kkj_cnt >= PIX_NUM + 128 && kkj_cnt <= PIX_NUM * 2 + 127) begin
      kkj_lv <= 1'b1;
    end else if (kkj_cnt >= PIX_NUM * 2 + 160 && kkj_cnt <= PIX_NUM * 3 + 159) begin
      kkj_lv <= 1'b1;
    end else begin
      kkj_lv <= 1'b0;
    end
  end





endmodule
