
//////////////////////////////////////////////////////////////////////////////////////////////
`timescale 1ns/1ps
//-------------------------------------------------------------------------------------------------

module   async_fifo_top #(
  parameter DATA_WIDTH    = 36        ,
  parameter ADDR_WIDTH    = 10        ,
  parameter COUNT_PORT    = "DISABLE" ,  // "DISABLE","ENABLE"
  parameter FIFO_FWFT     = "FALSE"   ,  // "FALSE", "TRUE"
  parameter DEVICE_FAMILY = "ASIC"       //"Xilinx", "Cyclone V", "REGS", "ASIC"
)
(
  input                          arst    ,
  input                          wclk    ,
  input                          wren    ,
  input      [DATA_WIDTH-1:0]    din     ,
  input                          rclk    ,
  input                          rden    ,
  output     [DATA_WIDTH-1:0]    dout    ,
  output reg [ADDR_WIDTH:0]      wr_count,//wr clk fifo count
  output reg [ADDR_WIDTH:0]      rd_count,//rd clk fifo count
  output reg                     empty   ,
  output reg                     full
);
  //---------------------------------------------
  //--  Register and Parameter
  //---------------------------------------------
  wire                      fwren         ;// filter wren
  wire                      frden         ;// filter rden
  wire                      full_pre      ;
  wire                      empty_pre     ;

  reg   [ADDR_WIDTH:0]      wptr_bin      ;//binary address
  reg   [ADDR_WIDTH:0]      wptr_gray     ;//gray address
  reg   [ADDR_WIDTH:0]      wptr_gray_d1  ;//in rclk
  reg   [ADDR_WIDTH:0]      wptr_gray_d2  ;//in rclk
  wire  [ADDR_WIDTH:0]      wptr_bin_next ;
  wire  [ADDR_WIDTH:0]      wptr_gray_next;

  reg   [ADDR_WIDTH:0]      rptr_bin      ;//binary address
  reg   [ADDR_WIDTH:0]      rptr_gray     ;//gray address
  reg   [ADDR_WIDTH:0]      rptr_gray_d1  ;//in wclk
  reg   [ADDR_WIDTH:0]      rptr_gray_d2  ;//in wclk
  wire  [ADDR_WIDTH:0]      rptr_bin_next ;
  wire  [ADDR_WIDTH:0]      rptr_gray_next;

  //For fifo usedrw count
  wire  [ADDR_WIDTH:0]      rptr_bin_con  ;//conver from gray code, wclk
  wire  [ADDR_WIDTH:0]      wptr_bin_con  ;//conver from gray code, rclk

  wire  [ADDR_WIDTH-1:0]    ram_waddr     ;
  wire  [ADDR_WIDTH-1:0]    ram_raddr     ;
  wire                      ram_rden      ;
  //---------------------------------------------
  //--  Read/Write Pointers Logic
  //---------------------------------------------
  assign   fwren = wren & (~full); //full protect
  assign   frden = rden & (~empty);//empty protect

  //wr address control
  always @ (posedge wclk or posedge arst)
  begin
    if(arst)
      wptr_bin <= {ADDR_WIDTH+1{1'b0}};
    else if(fwren)
      wptr_bin <= wptr_bin_next;
  end

  always @ (posedge wclk or posedge arst)
  begin
    if(arst)
      wptr_gray <= {ADDR_WIDTH+1{1'b0}};
    else if(fwren)
      wptr_gray <= wptr_gray_next;
  end

  assign  wptr_bin_next  = wptr_bin + 1'b1;
  assign  wptr_gray_next = wptr_bin_next ^ (wptr_bin_next>>1); //binary to gray


  //rd address control
  always @ (posedge rclk or posedge arst)
  begin
    if(arst)
      rptr_bin <= {ADDR_WIDTH+1{1'b0}};
    else if(frden)
      rptr_bin <= rptr_bin_next;
  end

  always @ (posedge rclk or posedge arst)
  begin
    if(arst)
      rptr_gray <= {ADDR_WIDTH+1{1'b0}};
    else if(frden)
      rptr_gray <= rptr_gray_next;
  end

  assign  rptr_bin_next  = rptr_bin + 1'b1;
  assign  rptr_gray_next = rptr_bin_next ^ (rptr_bin_next>>1); //binary to gray
  //---------------------------------------------
  //--  Synchronization Logic
  //---------------------------------------------
  //full flag
  always @ (posedge wclk or posedge arst)
  begin
    if(arst) begin
      rptr_gray_d1 <= {ADDR_WIDTH+1{1'b0}};
      rptr_gray_d2 <= {ADDR_WIDTH+1{1'b0}};
    end
    else begin
      rptr_gray_d1 <= rptr_gray   ;
      rptr_gray_d2 <= rptr_gray_d1;
    end
  end

  always @ (posedge wclk or posedge arst)
  begin
    if(arst)
      full <= 1'b0;
    else
      full <= full_pre;
  end

  assign full_pre = ( {~rptr_gray_d2[ADDR_WIDTH:ADDR_WIDTH-1],rptr_gray_d2[ADDR_WIDTH-2:0]}==wptr_gray)? 1'b1:
                    (({~rptr_gray_d2[ADDR_WIDTH:ADDR_WIDTH-1],rptr_gray_d2[ADDR_WIDTH-2:0]}==wptr_gray_next) && fwren)? 1'b1: 1'b0;

  //empty flag
  always @ (posedge rclk or posedge arst)
  begin
    if(arst) begin
      wptr_gray_d1 <= {ADDR_WIDTH+1{1'b0}};
      wptr_gray_d2 <= {ADDR_WIDTH+1{1'b0}};
    end 
    else begin
      wptr_gray_d1 <= wptr_gray   ;
      wptr_gray_d2 <= wptr_gray_d1;
    end
  end

  always @ (posedge rclk or posedge arst)
  begin
    if(arst)
      empty <= 1'b1;
    else
      empty <= empty_pre;
  end

  assign empty_pre = (wptr_gray_d2==rptr_gray)? 1'b1:
                     ((wptr_gray_d2==rptr_gray_next) && frden)? 1'b1: 1'b0;
  //---------------------------------------------
  //--  fifo count generate
  //---------------------------------------------
  generate
    if(COUNT_PORT=="ENABLE") begin
      //wr fifo count
      always @ (posedge wclk or posedge arst)
      begin
        if(arst)
          wr_count <= {ADDR_WIDTH+1{1'b0}};
        else if( wptr_bin > rptr_bin_con )
          wr_count <= wptr_bin - rptr_bin_con;
        else
          wr_count <= wptr_bin + (~rptr_bin_con) + 1'b1;
      end

      //read fifo count
      always @ (posedge rclk or posedge arst)
      begin
        if(arst)
          rd_count <= {ADDR_WIDTH+1{1'b0}};
        else if( wptr_bin_con > rptr_bin )
          rd_count <= wptr_bin_con - rptr_bin;
        else
          rd_count <= wptr_bin_con + (~rptr_bin) + 1'b1;
      end

      assign  rptr_bin_con = rptr_gray_d2 ^ (rptr_bin_con>>1);//convert gray to binary
      assign  wptr_bin_con = wptr_gray_d2 ^ (wptr_bin_con>>1);//convert gray to binary

    end
  endgenerate

  assign ram_waddr = wptr_bin[ADDR_WIDTH-1:0];

  //---------------------------------------------
  //--  fifo fwft mode select
  //---------------------------------------------
  generate
    if(FIFO_FWFT=="TRUE")  begin
      assign  ram_raddr = (frden)? rptr_bin_next[ADDR_WIDTH-1:0]: rptr_bin[ADDR_WIDTH-1:0];
      assign  ram_rden  = 1'b1;
    end
    else begin
      assign  ram_raddr = rptr_bin[ADDR_WIDTH-1:0];
      assign  ram_rden  = frden;
    end
  endgenerate

  //simgle dual port ram
  ram_sdp # (
    .ADDR_WIDTH     ( ADDR_WIDTH     ),
    .DATA_WIDTH     ( DATA_WIDTH     ),
    .DO_REG         ( 1'b0           ),
    .DEVICE_FAMILY  ( DEVICE_FAMILY  )
  )
  u_ram_sdp (
    .enwp           ( 1'b1           ),
    .wrclk          ( wclk           ),
    .wraddr         ( ram_waddr      ),
    .wr_en          ( fwren          ),
    .wr_dat         ( din            ),
    .enrp           ( 1'b1           ),
    .rdclk          ( rclk           ),
    .rdaddr         ( ram_raddr      ),
    .rd_en          ( ram_rden       ),
    .rd_dat         ( dout           )
  );

endmodule