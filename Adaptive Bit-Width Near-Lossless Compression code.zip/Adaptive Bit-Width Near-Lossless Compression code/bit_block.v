module bit_block#(
    parameter DATA_WIDTH         = 14,
    parameter TAPS               = 4
)
(
    input                            clk,
    input                            sensor_clk_x4,
    input                            reset,
    input                            newframe,
    
    input      [ 1 :0]               bit_flag,
    input                            negative_sign,
    input                            pix_vaild,
    input   [DATA_WIDTH*TAPS - 1 :0] data,
    input                            data_valid,
    input                            fifo_insert_done_all, 
    input                            frequency_rd_flag,

    output                           fifo_insert_done,  
    output  [7 :0]                   data_out,       //  rgb data
    output                           data_out_valid

);

/***************** freq_data_convert *********************/
freq_data_convert#(
    .DATA_WIDTH(8),//         = 14,
    .LINE_WIDTH(11),//         = 12,
    .PIX_WIDTH (11),//         = 12,
    .TAPS      (1)//         = 4
)freq_data_convert(
    .clk(clk),//input                            
    .sensor_clk_x4(sensor_clk_x4),//input                            
    .LINE(11'd1024),   //行数//input       [LINE_WIDTH-1:0]     
    .PIX(11'd1280),    //每行的像素数//input       [PIX_WIDTH-1:0]      
    .reset(reset),//input                            
    .newframe(newframe),//input                            
        //                                 
    .bit_flag(bit_flag),//input      [ 1 :0]               
    .negative_sign(negative_sign),//input     
    .pix_vaild(pix_vaild),                       
    .data(data),//input   [DATA_WIDTH*TAPS - 1 :0] 
    .data_valid(data_valid),//input  
    .fifo_insert_done_all(fifo_insert_done_all),  
    .frequency_rd_flag  (frequency_rd_flag), 

    .fifo_insert_done(fifo_insert_done),                          
    .data_out(data_out),       //  rgb data//output  [3 :0]                   
    .data_out_valid(data_out_valid)//output                           

);



// reg   [11:0]  cnt_2bit;     //记录一行中2bit范围之内的数据量  -1  0  1
// reg   [9:0]   block_2bit_cnt;
// reg   [9:0]   block_4bit_cnt;
// reg   [9:0]   block_6bit_cnt;
// reg   [9:0]   block_8bit_cnt;


// reg  data_valid_0;
// reg  data_valid_1;
// reg  data_valid_2;
// reg  data_valid_3;
// reg  data_valid_4;

//   always@(posedge clk) begin
//         data_valid_0 <= data_valid;
//         data_valid_1 <= data_valid_0;
//         data_valid_2 <= data_valid_1;
//         data_valid_3 <= data_valid_2;
//         data_valid_4 <= data_valid_3;
//     end
// /******************记录行和列*********************/
// reg  [10:0] pix_cnt;
// reg  [9:0] line_cnt;
// always@(posedge clk)
// 	begin
// 	  if(reset) begin
// 	  	pix_cnt<=11'd0;
// 	  end
// 	  else if(data_valid) begin
// 	    pix_cnt<=pix_cnt+11'd1;
// 	  end
// 	  else begin
// 	    pix_cnt<=11'd0;
// 	  end 
// 	end

//   always@(posedge clk)
//   begin
//     if(reset || newframe) begin
//         line_cnt<=10'd0;
//     end
//     else if(data_valid && !data_valid_0) begin
//         line_cnt<= line_cnt+10'd1;
//     end
//     else begin
//         line_cnt<= line_cnt ;
//     end
//   end
// /******************两个像素计数*********************/
// reg   [2:0] wr_en_cnt;
//     always@(posedge clk) begin
//      if(reset|| newframe)
//         wr_en_cnt <= 3'd0;     
//      else if(data_valid || data_valid_0)begin
//         if(wr_en_cnt == 3'd2)
//            wr_en_cnt <= 3'd1;           
//         else
//            wr_en_cnt <= wr_en_cnt + 1'd1;
//      end
//      else
//         wr_en_cnt <= 3'd0;          
//     end

// reg  [3:0]  data_reg0;
// reg  [3:0]  data_reg1;
// reg  [3:0]  data_reg2;
// reg  [3:0]  data_reg3;
// reg  [4:0]  data_bit_cnt;

//     always@(posedge clk) begin
//      if(reset|| newframe)begin
//         cnt_2bit <= 12'd0;
//         block_2bit_cnt <= 10'd0;
//         block_4bit_cnt <= 10'd0;
//         block_6bit_cnt <= 10'd0;
//         block_8bit_cnt <= 10'd0; 
//         data_reg0      <= 4'd0;
//         data_reg1      <= 4'd0;
//         data_reg2      <= 4'd0;
//         data_bit_cnt   <= 5'd0;
//      end
//      else if(!data_valid_0 & data_valid)begin     //第一行中的第一个数据
//         if(data < 8'd2)begin    //2bit      -1  0  1
//             cnt_2bit       <= cnt_2bit + 1'b1;
//             block_2bit_cnt <= block_2bit_cnt + 1'b1;
//             block_4bit_cnt <= 10'd0; 
//             block_6bit_cnt <= 10'd0;
//             block_8bit_cnt <= 10'd0;
//             data_reg0      <= {2'd0,data[1:0]};
//             data_reg1      <= 4'd0;
//             data_reg2      <= 4'd0;
//             data_bit_cnt   <= 5'd2;
//         end
//         else if((data < 8'd10) && (data >= 8'd2))begin   //4bit
//             cnt_2bit       <= 12'd0;
//             block_2bit_cnt <= 10'd0;
//             block_4bit_cnt <= block_4bit_cnt + 1'b1; 
//             block_6bit_cnt <= 10'd0;
//             block_8bit_cnt <= 10'd0;
//             data_reg0      <= 4'd0;
//             data_reg1      <= data[3:0];
//             data_reg2      <= 4'd0;
//             data_bit_cnt   <= 5'd4;
//         end
//         else if((data < 8'd42) && (data >= 8'd10))begin   //6bit
//             cnt_2bit       <= 12'd0;
//             block_2bit_cnt <= 10'd0;
//             block_4bit_cnt <= 10'd0;
//             block_6bit_cnt <= block_6bit_cnt + 1'b1; 
//             block_8bit_cnt <= 10'd0;
//             data_reg0      <= data[3:0];
//             data_reg1      <= {2'd0,data[5:4]};
//             data_reg2      <= 4'd0;
//             data_bit_cnt   <= 5'd6;
//         end
//         else if((data < 8'd255) && (data >= 8'd42))begin   //8bit
//             cnt_2bit       <= 12'd0;
//             block_2bit_cnt <= 10'd0;
//             block_4bit_cnt <= 10'd0;
//             block_6bit_cnt <= 10'd0;
//             block_8bit_cnt <= block_8bit_cnt + 1'b1; 
//             data_reg0      <= data[3:0];
//             data_reg1      <= data[7:4];
//             data_reg2      <= 4'd0;
//             data_bit_cnt   <= 5'd8;
//         end
//      end
//      else if((wr_en_cnt == 2'd2) && (data_valid))begin    
//         if(data < 8'd2)begin    //2bit      -1  0  1
//             if((data_bit_cnt == 4'd0) || (data_bit_cnt == 4'd4) || (data_bit_cnt == 4'd8))begin
//                 cnt_2bit       <= cnt_2bit + 1'b1;
//                 block_2bit_cnt <= block_2bit_cnt + 1'b1;
//                 block_4bit_cnt <= 10'd0;
//                 block_6bit_cnt <= 10'd0;
//                 block_8bit_cnt <= 10'd0;
//                 data_reg0      <= {2'd0,data[1:0]};
//                 data_reg1      <= 4'd0;
//                 data_reg2      <= 4'd0;
//                 data_bit_cnt   <= 5'd2;               
//             end
//             else if ((data_bit_cnt == 4'd2) || (data_bit_cnt == 4'd6) ||  (data_bit_cnt == 4'd10)) begin
//                 cnt_2bit       <= cnt_2bit + 1'b1;
//                 block_2bit_cnt <= block_2bit_cnt + 1'b1;
//                 block_4bit_cnt <= 10'd0;
//                 block_6bit_cnt <= 10'd0;
//                 block_8bit_cnt <= 10'd0;
//                 data_reg0      <= (data_bit_cnt == 4'd10) ? {data[1:0],data_reg2[1:0]} : ((data_bit_cnt == 4'd6) ? {data[1:0],data_reg1[1:0]} : {data[1:0],data_reg0[1:0]});
//                 data_reg1      <= 4'd0;
//                 data_reg2      <= 4'd0;
//                 data_bit_cnt   <= 5'd4;        
//             end
//         end
//         else if((data < 8'd10) && (data >= 8'd2)) begin     //4bit      
//             if((data_bit_cnt == 4'd0) || (data_bit_cnt == 4'd4) || (data_bit_cnt == 4'd8))begin
//                 cnt_2bit       <= cnt_2bit ;
//                 block_2bit_cnt <= 10'd0;
//                 block_4bit_cnt <=  (block_4bit_cnt == 4'd4) ?  4'd1 : (block_4bit_cnt + 1'b1);
//                 block_6bit_cnt <= 10'd0;
//                 block_8bit_cnt <= 10'd0;
//                 data_reg0      <= data[3:0];
//                 data_reg1      <= 4'd0;
//                 data_reg2      <= 4'd0;
//                 data_bit_cnt   <= 5'd4;               
//             end
//             else if ((data_bit_cnt == 4'd2) || (data_bit_cnt == 4'd6) || (data_bit_cnt == 4'd10)) begin 
//                 cnt_2bit       <= cnt_2bit ;
//                 block_2bit_cnt <= 10'd0;
//                 block_4bit_cnt <= (block_4bit_cnt == 4'd4) ?  4'd1 : (block_4bit_cnt + 1'b1);
//                 block_6bit_cnt <= 10'd0;
//                 block_8bit_cnt <= 10'd0;
//                 data_reg0      <= (data_bit_cnt == 4'd10) ? {data[1:0],data_reg2[1:0]} : ((data_bit_cnt == 4'd6) ? {data[1:0],data_reg1[1:0]} : {data[1:0],data_reg0[1:0]});
//                 data_reg1      <= {2'd0,data[3:2]};
//                 data_reg2      <= 4'd0;
//                 data_bit_cnt   <= 5'd6;        
//             end
//         end
//         else if((data < 8'd42) && (data >= 8'd10)) begin     //6bit      
//             if((data_bit_cnt == 4'd0) || (data_bit_cnt == 4'd4) || (data_bit_cnt == 4'd8))begin
//                 cnt_2bit       <= cnt_2bit ;
//                 block_2bit_cnt <= 10'd0;
//                 block_4bit_cnt <= 10'd0;
//                 block_6bit_cnt <= (block_6bit_cnt == 4'd4) ?  4'd1 : (block_6bit_cnt + 1'b1);
//                 block_8bit_cnt <= 10'd0;
//                 data_reg0      <= data[3:0];
//                 data_reg1      <= {2'd0,data[5:4]};
//                 data_reg2      <= 4'd0;
//                 data_bit_cnt   <= 5'd6;               
//             end
//             else if ((data_bit_cnt == 4'd2) || (data_bit_cnt == 4'd6) || (data_bit_cnt == 4'd10)) begin 
//                 cnt_2bit       <= cnt_2bit ;
//                 block_2bit_cnt <= 10'd0;
//                 block_4bit_cnt <= 10'd0;
//                 block_6bit_cnt <= (block_6bit_cnt == 4'd4) ?  4'd1 : (block_6bit_cnt + 1'b1);
//                 block_8bit_cnt <= 10'd0;
//                 data_reg0      <= (data_bit_cnt == 4'd10) ? {data[1:0],data_reg2[1:0]} : ((data_bit_cnt == 4'd6) ? {data[1:0],data_reg1[1:0]} : {data[1:0],data_reg0[1:0]});
//                 data_reg1      <= data[5:2];
//                 data_reg2      <= 4'd0;
//                 data_bit_cnt   <= 5'd8;        
//             end
//         end
//         else if((data < 8'd255) && (data >= 8'd42)) begin     //8bit      
//             if((data_bit_cnt == 4'd0) || (data_bit_cnt == 4'd4) || (data_bit_cnt == 4'd8))begin
//                 cnt_2bit       <= cnt_2bit ;
//                 block_2bit_cnt <= 10'd0;
//                 block_4bit_cnt <= 10'd0;
//                 block_6bit_cnt <= 10'd0;
//                 block_8bit_cnt <= (block_8bit_cnt == 4'd4) ?  4'd1 : (block_8bit_cnt + 1'b1);
//                 data_reg0      <= data[3:0];
//                 data_reg1      <= data[7:4];
//                 data_reg2      <= 4'd0;
//                 data_bit_cnt   <= 5'd8;               
//             end
//             else if ((data_bit_cnt == 4'd2) || (data_bit_cnt == 4'd6) || (data_bit_cnt == 4'd10)) begin 
//                 cnt_2bit       <= cnt_2bit ;
//                 block_2bit_cnt <= 10'd0;
//                 block_4bit_cnt <= 10'd0;
//                 block_6bit_cnt <= 10'd0;
//                 block_8bit_cnt <= (block_8bit_cnt == 4'd4) ?  4'd1 : (block_8bit_cnt + 1'b1);
//                 data_reg0      <= (data_bit_cnt == 4'd10) ? {data[1:0],data_reg2[1:0]} : ((data_bit_cnt == 4'd6) ? {data[1:0],data_reg1[1:0]} : {data[1:0],data_reg0[1:0]});
//                 data_reg1      <= data[5:2];
//                 data_reg2      <= {2'd0,data[7:6]};
//                 data_bit_cnt   <= 5'd10;        
//             end
//         end
//      end
//      else if(data_valid )begin 
//                 cnt_2bit       <= cnt_2bit      ;
//                 block_2bit_cnt <= block_2bit_cnt;
//                 block_4bit_cnt <= block_4bit_cnt;
//                 block_6bit_cnt <= block_6bit_cnt;
//                 block_8bit_cnt <= block_8bit_cnt;
//                 data_reg0      <= data_reg0     ;
//                 data_reg1      <= data_reg1     ;
//                 data_reg2      <= data_reg2     ;
//                 data_bit_cnt   <= data_bit_cnt  ;
//      end
//      else begin 
//                 cnt_2bit       <= 12'd0; 
//                 block_2bit_cnt <= 10'd0;
//                 block_4bit_cnt <= 10'd0;
//                 block_6bit_cnt <= 10'd0;
//                 block_8bit_cnt <= 10'd0;
//                 data_reg0      <= 4'd0;
//                 data_reg1      <= 4'd0;
//                 data_reg2      <= 4'd0;
//                 data_bit_cnt   <= 5'd0;
//      end
//     end

// reg [1:0] bit_flag_dly;
// reg [1:0] bit_flag_dly_1;
// reg [4:0] data_bit_cnt_dly;
//     always@(posedge clk) begin
//      if(reset|| newframe)begin
//         bit_flag_dly   <= 2'd0;
//         bit_flag_dly_1 <= 2'd0;    
//         data_bit_cnt_dly <= 5'd0; 
//      end
//      else begin
//         bit_flag_dly   <= bit_flag;
//         bit_flag_dly_1 <= bit_flag_dly;  
//         data_bit_cnt_dly <= data_bit_cnt; 
//      end

//      end

// reg detained_flag;
// reg ram_wr_en;
// reg [1:0] bit_range;
// reg [9:0] block_cnt_reg;
// reg [8:0] ram_wr_addr;
// reg [12:0] ram_wr_data;
// reg  block_once;
//     always@(posedge clk) begin
//      if(reset|| newframe)begin
//         detained_flag <= 1'b1;
//         bit_range     <= 2'd0;
//         ram_wr_en     <= 1'b0;
//         block_cnt_reg <= 10'd0;
//         ram_wr_addr   <= 9'd0;
//         block_once    <= 1'b0;
//      end
//     //  else if(data_valid_0 || data_valid)begin
//      else if(data_valid_0)begin
//         if((bit_flag != bit_flag_dly)  && (!block_once))begin
//             detained_flag <= ((data_bit_cnt_dly == 5'd2) || (data_bit_cnt_dly == 5'd6) || (data_bit_cnt_dly == 5'd10)) ? 1'd1 : 1'd0;
//             bit_range     <= bit_flag_dly;
//             ram_wr_en     <= 1'b1; 
//             block_cnt_reg <= (bit_flag_dly == 2'd3) ? block_8bit_cnt : ((bit_flag_dly == 2'd2) ? block_6bit_cnt : ((bit_flag_dly == 2'd1) ? block_4bit_cnt : block_2bit_cnt));           
//             ram_wr_addr   <= ram_wr_addr + 1'b1;
//             block_once    <= 1'b0;
//         end
//         else if((!data_valid & data_valid_0)  && (!block_once))begin
//             // detained_flag <= ((data_bit_cnt_dly == 5'd2) || (data_bit_cnt_dly == 5'd6) || (data_bit_cnt_dly == 5'd10)) ? 1'd1 : 1'd0;
//             detained_flag <=  1'd0;
//             bit_range     <= bit_flag_dly;
//             ram_wr_en     <= 1'b1; 
//             block_cnt_reg <= (bit_flag_dly == 2'd3) ? block_8bit_cnt : ((bit_flag_dly == 2'd2) ? block_6bit_cnt : ((bit_flag_dly == 2'd1) ? block_4bit_cnt : block_2bit_cnt));           
//             ram_wr_addr   <= ram_wr_addr + 1'b1;
//             block_once    <= 1'b0;
//         end
//         else if(((block_4bit_cnt == 9'd4) || (block_6bit_cnt == 9'd4) || (block_8bit_cnt == 9'd4)) && (!block_once))begin
//             detained_flag <= ((data_bit_cnt_dly == 5'd2) || (data_bit_cnt_dly == 5'd6) || (data_bit_cnt_dly == 5'd10)) ? 1'd1 : 1'd0;
//             bit_range     <= bit_flag;
//             ram_wr_en     <= 1'b1; 
//             block_cnt_reg <= (bit_flag_dly == 2'd3) ? block_8bit_cnt : ((bit_flag_dly == 2'd2) ? block_6bit_cnt : ((bit_flag_dly == 2'd1) ? block_4bit_cnt : block_2bit_cnt));           
//             ram_wr_addr   <= ram_wr_addr + 1'b1;
//             block_once    <= 1'b1;
//         end
//         else begin
//             detained_flag <= 1'd0;
//             bit_range     <= 2'd0;
//             ram_wr_en     <= 1'b0;
//             block_cnt_reg <= 10'd0;
//             ram_wr_addr   <= ram_wr_addr;
//             block_once    <= 1'b0;
//         end    
//      end
//      else begin
//          detained_flag <= 1'd0;
//          bit_range     <= 2'd0;
//          ram_wr_en     <= 1'b0;
//          block_cnt_reg <= 10'd0;
//          ram_wr_addr   <= 9'd0;
//          block_once    <= 1'b0;
//      end    
//     end
// // assign  ram_wr_data = {detained_flag,bit_range,block_cnt_reg};

// reg [7:0]  ram_rd_addr;
//     always@(posedge clk) begin
//      if(reset|| newframe)
//         ram_wr_data  <=  13'd0;
//      else
//         ram_wr_data  <= {detained_flag,bit_range,block_cnt_reg};
//     end

// reg ram_wr_en_dly;
// reg [8:0] ram_wr_addr_dly;
//     always@(posedge clk) begin
//      if(reset|| newframe)begin     
//          ram_wr_en_dly <= 1'b0;
//          ram_wr_addr_dly <= 9'd0;
//      end
//      else begin
//          ram_wr_en_dly <= ram_wr_en;
//          ram_wr_addr_dly <= ram_wr_addr;
//      end
//     end

// wire [12:0] ram_rd_data;
// block_parameter_storage block_parameter_storage(
//     // Inputs
//     .CLK(clk)   ,   //      
//     .R_ADDR(ram_rd_addr_reg),   //[8:0] 
//     .W_ADDR(ram_wr_addr_dly),   //[8:0] 
//     .W_DATA(ram_wr_data),   //[12:0]
//     .W_EN(ram_wr_en_dly)  ,   //      
//     // Outputs
//     .R_DATA(ram_rd_data)    //[12:0]
// );

// /**************按照 block_parameter_storage 存进的各个范围bit的参数来对fifo进行读取****************/
// wire empty;
// wire full;
// wire [10:0] rdcnt;
// line_buffer_4bit line_buffer_4bit(
//     // Inputs
//     .CLK    (clk),
//     .DATA   (wr_data),
//     .RE     (fifo_rd_en_dly),
//     .RESET_N(!newframe),
//     .WE     (fifo_wr_en),
//     // Outputs
//     .EMPTY  (empty),
//     .FULL   (full),
//     .Q      (rd_data),
//     .RDCNT  (rdcnt)
// );

// reg  fifo_wr_en;
// reg  fifo_rd_en;
// reg   fifo_rd_en_dly;
// reg   fifo_rd_en_dly_0;
// reg   fifo_rd_en_dly_1;
// reg  [3:0] wr_data;
// reg  [3:0] rd_data;
//     always@(posedge clk) begin
//      if(reset|| newframe)begin
//         fifo_wr_en <= 1'b0;
//         wr_data    <= 4'd0;
//      end
//      else if(data_valid_0 || data_valid)begin
//         if(data_valid_1 & !data_valid_0)begin
//             fifo_wr_en <=  ((data_bit_cnt == 5'd10) || (data_bit_cnt == 5'd6)) ? 1'b1 : 1'b0;
//             wr_data    <= {2'd0,data_reg2[1:0]};   
//         end
//         else if((data_bit_cnt == 5'd4) || (data_bit_cnt == 5'd6))begin
//             fifo_wr_en <= (wr_en_cnt == 3'd1) ? 1'b1 : 1'b0;
//             wr_data    <= (wr_en_cnt == 3'd1) ? data_reg0 : 4'd0 ;
//         end
//         else if((data_bit_cnt == 5'd8) || (data_bit_cnt == 5'd10))begin
//             fifo_wr_en <=  1'b1 ;
//             wr_data    <= (wr_en_cnt == 3'd1) ? data_reg0 : data_reg1;   
//         end

//         else begin
//             fifo_wr_en <= 1'b0;
//             wr_data    <= 4'd0;
//         end
//      end
//      else begin
//          fifo_wr_en <= 1'b0;
//          wr_data    <= 4'd0;
//      end 
//     end

//    //  always@(posedge clk) begin
//    //   if(reset|| newframe)
//    //      fifo_rd_en  <=  8'd0;
//    //   else
//    //      fifo_rd_en  <= fifo_wr_en;
//    //  end
// reg  [8:0] ram_wr_addr_reg;   //记录一行写入了多少的数据块
// reg  [8:0] ram_rd_addr_reg;
// reg  [8:0] ram_rd_addr_reg_dly;
// reg  [8:0] ram_rd_addr_reg_dly_0;
//     always@(posedge clk) begin
//      if(reset|| newframe)
//         ram_wr_addr_reg  <=  9'd0;
//      else if(!data_valid_0 & data_valid_1)
//         ram_wr_addr_reg  <=  ram_wr_addr;
//     end

//     always@(posedge clk) begin
//      if(reset|| newframe)begin
//         ram_rd_addr_reg_dly  <=  9'b0;
//         ram_rd_addr_reg_dly_0 <=  9'b0;     
//      end
//      else begin
//         ram_rd_addr_reg_dly  <=  ram_rd_addr_reg;
//         ram_rd_addr_reg_dly_0 <= ram_rd_addr_reg_dly;
//      end     
//     end

//     always@(posedge clk) begin
//      if(reset|| newframe)
//         ram_rd_addr_reg  <=  9'b0;
//     //  else if(!data_valid_0 & data_valid)
//    //   else if(fifo_rd_en_cnt_all >= fifo_wr_en_cnt_reg)
//    //      ram_rd_addr_reg  <=  9'b0;   
//      else if((ram_rd_addr_reg == ram_wr_addr_reg + 1'b1) || (fifo_rd_en_cnt_all == fifo_wr_en_cnt_reg))
//         ram_rd_addr_reg  <=  9'b0;
//     //  else if(pix_cnt == 11'd640)
//      else if(data_valid_3 & !data_valid_2)
//         ram_rd_addr_reg  <= 9'b1;
//      else if((fifo_rd_en_cnt == fifo_rd_en_cnt_constraint) || (fifo_rd_en_cnt_all >= fifo_wr_en_cnt_reg))
//         ram_rd_addr_reg  <= ram_rd_addr_reg + 1'b1;
//      else 
//         ram_rd_addr_reg  <=  ram_rd_addr_reg;
//     end
// reg  [10 : 0] fifo_wr_en_cnt;
// reg  [10 : 0] fifo_wr_en_cnt_reg;
//     always@(posedge clk) begin
//       if(reset|| newframe)begin
//          fifo_wr_en_cnt <= 11'd0;
//          fifo_wr_en_cnt_reg <= 11'd2;
//       end
//       else if(!data_valid_3 & data_valid_4)begin
//          fifo_wr_en_cnt <= 11'd0;
//          fifo_wr_en_cnt_reg <= fifo_wr_en_cnt;
//       end
//       else if(data_valid_1 || data_valid_4)begin
//          if(fifo_wr_en)begin
//             fifo_wr_en_cnt <= fifo_wr_en_cnt + 1'b1;
//             fifo_wr_en_cnt_reg <= fifo_wr_en_cnt_reg;   
//          end
//          else begin
//             fifo_wr_en_cnt <= fifo_wr_en_cnt; 
//             fifo_wr_en_cnt_reg <= fifo_wr_en_cnt_reg; 
//          end
//       end
//       else begin
//          fifo_wr_en_cnt <= 11'd0;
//          fifo_wr_en_cnt_reg <= fifo_wr_en_cnt_reg;       
//       end
//     end
// reg  [10 : 0] fifo_rd_en_cnt_all;
//     always@(posedge clk) begin
//       if(reset|| newframe)
//          fifo_rd_en_cnt_all <= 11'd0;
//       else if(data_valid_0 & !data_valid )
//          fifo_rd_en_cnt_all <= 11'd0;
//       else if(fifo_rd_en_cnt_all == fifo_wr_en_cnt_reg )
//          fifo_rd_en_cnt_all <= fifo_wr_en_cnt_reg;
//       else if(fifo_rd_en)
//          fifo_rd_en_cnt_all <= fifo_rd_en_cnt_all + 1'b1;
//       else
//          fifo_rd_en_cnt_all <= fifo_rd_en_cnt_all;
//     end
// reg fifo_rd_en_prohibited;
//     always@(posedge clk) begin
//      if(reset|| newframe)
//          fifo_rd_en_prohibited <= 1'b0; 
//      else if(fifo_rd_en_cnt_all >= fifo_wr_en_cnt_reg - 1'b1)
//          fifo_rd_en_prohibited <= 1'b1; 
//      else if(data_valid_0 & !data_valid)
//          fifo_rd_en_prohibited <= 1'b0; 
//     end
// reg [8:0] fifo_rd_en_cnt;
// reg fifo_rd_en_cnt_flag;
//     always@(posedge clk) begin
//      if(reset|| newframe)begin
//         fifo_rd_en_cnt_flag  <=  1'b0;     
//         fifo_rd_en           <=  1'b0;  
//      end
//     //  else if(!data_valid_4 & data_valid_3)
//      else if(fifo_rd_en_cnt_all == fifo_wr_en_cnt_reg )begin
//         fifo_rd_en_cnt_flag  <=  1'b0;
//         fifo_rd_en           <=  1'b0;     
//      end
//      else if((ram_rd_addr_reg == ram_wr_addr_reg + 1'b1) || (ram_rd_addr_reg_dly == ram_wr_addr_reg + 1'b1) || (ram_rd_addr_reg_dly_0 == ram_wr_addr_reg + 1'b1))begin
//         fifo_rd_en_cnt_flag  <=  1'b0;
//         fifo_rd_en           <=  1'b0;     
//      end
//    //   else if(ram_rd_addr_reg_dly != ram_rd_addr_reg_dly_0)
//      else if((ram_rd_addr_reg_dly != ram_rd_addr_reg_dly_0)  && (ram_rd_data[11:10] == 2'd0) && (ram_rd_data[9:0] ==  1'b1) && detained_flag_reg_reg && !detained_flag_reg)begin
//         fifo_rd_en_cnt_flag  <=  1'b1;    
//         fifo_rd_en           <=  1'b0;          
//      end
     
//    //   else if((ram_rd_addr_reg_dly != ram_rd_addr_reg_dly_0) && (fifo_rd_en_prohibited))begin
//    //       fifo_rd_en_cnt_flag  <=  1'b1;
//    //       fifo_rd_en           <=  1'b0;
//    //   end
//      else if((ram_rd_addr_reg_dly != ram_rd_addr_reg_dly_0))begin
//          fifo_rd_en_cnt_flag  <=  1'b1;
//          fifo_rd_en           <=  1'b1;
//      end
//      else if(fifo_rd_en_cnt == fifo_rd_en_cnt_constraint - 1'b1)begin
//         fifo_rd_en_cnt_flag  <=  1'b0;  
//         fifo_rd_en           <=  1'b0;  
//      end
//     end

//     always@(posedge clk) begin
//      if(reset|| newframe)begin
//          fifo_rd_en_dly  <=  1'b0;  
//          fifo_rd_en_dly_0 <=  1'b0; 
//          fifo_rd_en_dly_1 <=  1'b0; 
//      end
//      else if(fifo_rd_en_cnt_all == fifo_wr_en_cnt_reg)begin
//         fifo_rd_en_dly  <=  1'b0;    
//         fifo_rd_en_dly_0 <=  fifo_rd_en_dly; 
//         fifo_rd_en_dly_1 <=  fifo_rd_en_dly_0; 
//      end
//      else begin
//         fifo_rd_en_dly <= fifo_rd_en;  
//         fifo_rd_en_dly_0 <=  fifo_rd_en_dly; 
//         fifo_rd_en_dly_1 <=  fifo_rd_en_dly_0;    
//      end
//      end


//     always@(posedge clk) begin
//      if(reset|| newframe)
//         fifo_rd_en_cnt  <=  12'd0;
//     //  else if(!data_valid_0 & data_valid)
//      else if((ram_rd_addr_reg == ram_wr_addr_reg + 1'b1) || (fifo_rd_en_cnt_all == fifo_wr_en_cnt_reg))
//         fifo_rd_en_cnt  <=  12'd0;
//      else if(fifo_rd_en_cnt == fifo_rd_en_cnt_constraint )
//         fifo_rd_en_cnt  <= 12'd0;
//      else if(fifo_rd_en_cnt_flag)
//         fifo_rd_en_cnt  <= fifo_rd_en_cnt + 1'b1;

//      else
//         fifo_rd_en_cnt  <= fifo_rd_en_cnt;
//     end

// reg  [8:0] fifo_rd_en_cnt_constraint;
// reg  [3:0] data_out_reg0;
// reg  [3:0] data_out_reg1;
// reg  [3:0] data_out_reg2;
// reg  [3:0] data_out_reg3;
// reg  [12:0]  ram_rd_data_dly;
// // reg          detained_flag_reg;     //从RAM中读出的每个块开头是否有2bit前一个块剩余数据的指示信号
// // reg          detained_flag_reg_reg;



//     always@(posedge clk) begin
//      if(reset|| newframe)
//         ram_rd_data_dly <= 13'd0;
//      else
//         ram_rd_data_dly <= ram_rd_data;
//      end
// wire          detained_flag_reg;     //从RAM中读出的每个块开头是否有2bit前一个块剩余数据的指示信号
// reg           detained_flag_reg_reg;
// reg           detained_flag_reg_reg_reg;
// assign detained_flag_reg = ram_rd_data[12];
// // assign detained_flag_reg_reg = (ram_rd_addr_reg_dly != ram_rd_addr_reg) ? detained_flag_reg : 1'd0;
//      always@(posedge clk) begin
//      if(reset|| newframe)begin
//         detained_flag_reg_reg <=  1'd0;
//         detained_flag_reg_reg_reg  <= 1'd0;
//      end
//      else if((ram_rd_addr_reg == ram_wr_addr_reg + 1'b1) || (fifo_rd_en_cnt_all == fifo_wr_en_cnt_reg))begin
//         detained_flag_reg_reg <=  1'd0;   
//         detained_flag_reg_reg_reg  <= 1'd0;
//      end
//      else if(ram_rd_addr_reg_dly != ram_rd_addr_reg)begin  
//         detained_flag_reg_reg <= (ram_rd_addr_reg > 9'd1) ? detained_flag_reg : 1'd0;
//         detained_flag_reg_reg_reg <= (ram_rd_addr_reg > 9'd2) ? detained_flag_reg_reg : 1'd0;
//      end
//      end

//    //  always@(posedge clk) begin
//    //   if(reset|| newframe)
//    //      fifo_rd_en_cnt_constraint <= 9'd0;
//    //   else if( ram_rd_data == 12'b0)   //一行fifo读取结束
//    //      fifo_rd_en_cnt_constraint <= fifo_rd_en_cnt_constraint;        
//    //   else if( (ram_rd_data[10:9] == 2'd0) && (ram_rd_data[0] ==  1'b0))   //偶数个2bit的数
//    //      fifo_rd_en_cnt_constraint <= ram_rd_data[8:0] >> 1;
//    //   else if( (ram_rd_data[10:9] == 2'd0) && (ram_rd_data[0] ==  1'b1))   //奇数个2bit的数
//    //      fifo_rd_en_cnt_constraint <= (ram_rd_data[8:0] + 1'b1) >> 1;
//    //   else if( (ram_rd_data[10:9] == 2'd1) && (ram_rd_data[0] ==  1'b1))   //偶数个4bit的数
//    //      fifo_rd_en_cnt_constraint <= ram_rd_data[8:0];
//    //   else if( (ram_rd_data[10:9] == 2'd1) && (ram_rd_data[0] ==  1'b1))   //奇数个4bit的数
//    //      fifo_rd_en_cnt_constraint <= ram_rd_data[8:0];
//    //   else if( (ram_rd_data[10:9] == 2'd2) && (ram_rd_data[0] ==  1'b1))   //偶数个6bit的数
//    //      fifo_rd_en_cnt_constraint <= (ram_rd_data[8:0]*6) >>2;
//    //   else if( (ram_rd_data[10:9] == 2'd2) && (ram_rd_data[0] ==  1'b1))   //奇数个6bit的数
//    //      fifo_rd_en_cnt_constraint <= (ram_rd_data[8:0]*6) >>2;
//    //   else if( (ram_rd_data[10:9] == 2'd3) && (ram_rd_data[0] ==  1'b1))   //偶数个8bit的数
//    //      fifo_rd_en_cnt_constraint <= ram_rd_data[8:0] << 1;
//    //   else if( (ram_rd_data[10:9] == 2'd3) && (ram_rd_data[0] ==  1'b1))   //奇数个8bit的数
//    //      fifo_rd_en_cnt_constraint <= ram_rd_data[8:0] << 1;  
//    //   else
//    //      fifo_rd_en_cnt_constraint <= fifo_rd_en_cnt_constraint;      
//    //  end

// //detained_flag_reg_reg 为 1 代表上一个块读取了本块2bit, detained_flag_reg 为 1 代表本块要读取下个块的2bit
// //   1   1
// //   1   0
// //   0   1
// //   0   0
//     always@(posedge clk) begin
//      if(reset|| newframe)
//         fifo_rd_en_cnt_constraint <= 9'd1;
//      else if( ram_rd_data == 13'b0)   //一行fifo读取结束
//         fifo_rd_en_cnt_constraint <= fifo_rd_en_cnt_constraint;        
//      else if( (ram_rd_data[11:10] == 2'd0) && (ram_rd_data[0] ==  1'b0) && !detained_flag_reg_reg && detained_flag_reg)   //偶数个2bit的数
//         fifo_rd_en_cnt_constraint <=  (ram_rd_data[9:0] >> 1) + 1'b1;
//      else if( (ram_rd_data[11:10] == 2'd0) && (ram_rd_data[0] ==  1'b0))   //偶数个2bit的数
//         fifo_rd_en_cnt_constraint <= ram_rd_data[9:0] >> 1;
//      else if( (ram_rd_data[11:10] == 2'd0) && (ram_rd_data[9:0] ==  1'b1) && detained_flag_reg_reg && !detained_flag_reg)  //1个2bit的数
//         fifo_rd_en_cnt_constraint <= 1'b1;  
//      else if( (ram_rd_data[11:10] == 2'd0) && (ram_rd_data[0] ==  1'b1) && detained_flag_reg_reg && !detained_flag_reg)  //奇数个2bit的数
//         fifo_rd_en_cnt_constraint <= (ram_rd_data[9:0] - 1'b1) >> 1;     
//      else if( (ram_rd_data[11:10] == 2'd0) && (ram_rd_data[0] ==  1'b1))   //奇数个2bit的数
//         fifo_rd_en_cnt_constraint <= (ram_rd_data[9:0] + 1'b1) >> 1;
//      else if( (ram_rd_data[11:10] == 2'd1)  && !detained_flag_reg_reg && detained_flag_reg)   //4bit的数
//         fifo_rd_en_cnt_constraint <= (ram_rd_data[9:0] + 1'b1);
//      else if( (ram_rd_data[11:10] == 2'd1) && (ram_rd_data[0] ==  1'b0))   //偶数个4bit的数
//         fifo_rd_en_cnt_constraint <= ram_rd_data[9:0];
//      else if( (ram_rd_data[11:10] == 2'd1) && (ram_rd_data[0] ==  1'b1))   //奇数个4bit的数
//         fifo_rd_en_cnt_constraint <= ram_rd_data[9:0];
//      else if( (ram_rd_data[11:10] == 2'd2) && (ram_rd_data[0] ==  1'b0)  && !detained_flag_reg_reg && detained_flag_reg)   //偶数个6bit的数
//         fifo_rd_en_cnt_constraint <= ((ram_rd_data[9:0]*6) >>2 ) + 1'b1;  
//      else if( (ram_rd_data[11:10] == 2'd2) && (ram_rd_data[0] ==  1'b0))   //偶数个6bit的数
//         fifo_rd_en_cnt_constraint <= (ram_rd_data[9:0]*6) >>2;
//      else if( (ram_rd_data[11:10] == 2'd2) && (ram_rd_data[0] ==  1'b1) && detained_flag_reg_reg && !detained_flag_reg)   //奇数个6bit的数
//         fifo_rd_en_cnt_constraint <= ((ram_rd_data[9:0]*6) >>2 );
//      else if( (ram_rd_data[11:10] == 2'd2) && (ram_rd_data[0] ==  1'b1))   //奇数个6bit的数
//         fifo_rd_en_cnt_constraint <= ((ram_rd_data[9:0]*6) >>2) + 1'b1;
//      else if( (ram_rd_data[11:10] == 2'd3)  && !detained_flag_reg_reg && detained_flag_reg)   //8bit的数
//         fifo_rd_en_cnt_constraint <= (ram_rd_data[9:0] << 1) + 1'b1;
//      else if( (ram_rd_data[11:10] == 2'd3) && (ram_rd_data[0] ==  1'b0))   //偶数个8bit的数
//         fifo_rd_en_cnt_constraint <= ram_rd_data[9:0] << 1;
//      else if( (ram_rd_data[11:10] == 2'd3) && (ram_rd_data[0] ==  1'b1))   //奇数个8bit的数
//         fifo_rd_en_cnt_constraint <= ram_rd_data[9:0] << 1;  
//      else
//         fifo_rd_en_cnt_constraint <= fifo_rd_en_cnt_constraint;      
//     end


// //detained_flag_reg_reg_reg     记录上一个 block 的 detained_flag_reg_reg
// //detained_flag_reg_reg         记录上一个 block 的 detained_flag_reg
// // /************** 插入指示信号 ********************/
// // reg [3:0] insert_data;
// // reg insert_data_en;
// //     always@(posedge clk) begin
// //       if(reset|| newframe)begin
// //          insert_data <= 4'd0;       
// //          insert_data_en <= 1'b0;
// //       end
// //       else if(ram_rd_addr_reg_dly != ram_rd_addr_reg_dly_0)begin
// //          if((ram_rd_addr_reg_dly_0 == 9'd0) || (ram_rd_data[11:10] == 2'd0))begin
// //             insert_data <= 4'd0;       
// //             insert_data_en <= 1'b0;               
// //          end
// //          else if(ram_rd_data[11:10] == 2'd1)begin    //4bit数据
// //                if((!detained_flag_reg_reg_reg && !detained_flag_reg_reg) || (detained_flag_reg_reg_reg && detained_flag_reg_reg))begin
// //                   insert_data <= {2'b01,2'b01};       // 大数指示信号，bit 范围指示信号，
// //                   insert_data_en <= 1'b1;       
// //                end
// //                else if((detained_flag_reg_reg_reg && !detained_flag_reg_reg) || (!detained_flag_reg_reg_reg && detained_flag_reg_reg))begin
// //                   insert_data <= {2'b01,2'b01};       // 大数指示信号，bit 范围指示信号，
// //                   insert_data_en <= 1'b1;       
// //                end
                  
// //             insert_data <= {2'b01,ram_rd_data[9:0]};       
// //             insert_data_en <= 1'b1;             
// //          end
// //          else if(ram_rd_data[11:10] == 2'd2)begin    //6bit数据
// //             insert_data <= {2'b10,ram_rd_data[9:0]};         
// //             insert_data_en <= 1'b1;  
// //          end
// //          else if(ram_rd_data[11:10] == 2'd3)begin    //8bit数据
// //             insert_data <= {2'b11,ram_rd_data[9:0]};        
// //             insert_data_en <= 1'b1;  
// //          end
// //          else begin 
// //             insert_data <= 4'd0;         
// //             insert_data_en <= 1'b0;  
// //          end
// //       end
// //       else begin
// //          insert_data <= 4'd0;       
// //          insert_data_en <= 1'b0;
// //       end
// //     end

// reg       detained_flag_reg_reg_reg_dly;  //延迟一次
// reg       detained_flag_reg_reg_dly;      //延迟一次
// reg       detained_flag_reg_dly    ;      //延迟一次
// reg       detained_flag_reg_reg_reg_dly_0;  //延迟二次
// reg       detained_flag_reg_reg_dly_0;      //延迟二次
// reg       detained_flag_reg_dly_0    ;      //延迟二次
// reg       detained_flag_reg_reg_reg_dly_1;  //延迟三次
// reg       detained_flag_reg_reg_dly_1;      //延迟三次
// reg       detained_flag_reg_dly_1    ;      //延迟三次

// reg       fifo_rd_en_dly_2         ;
// reg       fifo_rd_en_dly_3         ;
// reg [3:0] rd_data_dly              ;
// reg [8:0] fifo_rd_en_cnt_dly       ;
// reg [8:0] fifo_rd_en_cnt_dly_0     ;
// reg [8:0] fifo_rd_en_cnt_constraint_dly;
//     always@(posedge clk) begin
//       if(reset|| newframe)begin
//          detained_flag_reg_reg_reg_dly <= 1'b0;
//          detained_flag_reg_reg_dly <= 1'b0;
//          detained_flag_reg_dly     <= 1'b0;
//          detained_flag_reg_reg_reg_dly_0 <= 1'b0;
//          detained_flag_reg_reg_dly_0 <= 1'b0;    
//          detained_flag_reg_dly_0 <=  1'b0;  
//          detained_flag_reg_reg_reg_dly_1 <= 1'b0;
//          detained_flag_reg_reg_dly_1 <= 1'b0;  
//          detained_flag_reg_dly_1 <=  1'b0;   
//          fifo_rd_en_dly_2          <= 1'b0;
//          fifo_rd_en_dly_3          <= 1'b0;
//          rd_data_dly               <= 4'd0;
//          fifo_rd_en_cnt_dly        <= 9'd0;
//          fifo_rd_en_cnt_dly_0      <= 9'd0;

//       end
//       else begin
//          detained_flag_reg_reg_reg_dly <= detained_flag_reg_reg_reg;
//          detained_flag_reg_reg_dly <= detained_flag_reg_reg; //detained_flag_reg_reg 延迟一个时钟周期
//          detained_flag_reg_dly     <= detained_flag_reg;     //detained_flag_reg 延迟一个时钟周期
//          detained_flag_reg_reg_reg_dly_0 <= detained_flag_reg_reg_reg_dly;
//          detained_flag_reg_reg_dly_0 <= detained_flag_reg_reg_dly;    
//          detained_flag_reg_dly_0 <=  detained_flag_reg_dly;  
//          detained_flag_reg_reg_reg_dly_1 <= detained_flag_reg_reg_reg_dly_0;
//          detained_flag_reg_reg_dly_1 <= detained_flag_reg_reg_dly_0;  
//          detained_flag_reg_dly_1 <=  detained_flag_reg_dly_0;   
//          fifo_rd_en_dly_2          <= fifo_rd_en_dly_1;      //fifo_rd_en 延迟三个时钟周期
//          fifo_rd_en_dly_3          <= fifo_rd_en_dly_2;      //fifo_rd_en 延迟四个时钟周期
//          rd_data_dly               <= rd_data;               //rd_data 延迟两个时钟周期
//          fifo_rd_en_cnt_dly        <= fifo_rd_en_cnt;
//          fifo_rd_en_cnt_dly_0      <= fifo_rd_en_cnt_dly;    //fifo_rd_en_cnt 延迟两个时钟周期
//       end
//     end

// reg [3:0] rd_data_reg;
// reg [3:0] rd_data_reg_0;
// reg [2:0] end_en_cnt;
// reg end_en;
// reg [2:0] end_en_flag;    
// reg [3:0] insert_data;
// reg insert_data_en;
//     always@(posedge clk) begin
//       if(reset|| newframe)begin
//          rd_data_reg    <= 4'd0;       
//          rd_data_reg_0  <= 4'd0;    
//          insert_data    <= 4'd0;   
//          insert_data_en <= 1'b0; 
//          end_en         <= 1'b0;
//          end_en_cnt     <= 3'd0;
//          end_en_flag    <= 3'd0;
//       end
//       else if((fifo_rd_en_dly_1) || (end_en))begin
//          if(!fifo_rd_en_dly_2 & fifo_rd_en_dly_1)begin    //开头
//             if(ram_rd_data_dly[11:10] == 2'd0)begin
//                if((!detained_flag_reg_reg_dly && !detained_flag_reg_reg_reg_dly) || (!detained_flag_reg_reg_reg_dly && detained_flag_reg_reg_dly ))begin
//                   rd_data_reg   <= rd_data_dly;   
//                   rd_data_reg_0 <= 4'd0;
//                   insert_data    <= 4'd0;
//                   insert_data_en <= 1'b0;
//                   end_en         <= 1'b0;
//                   end_en_cnt     <= 3'd0;
//                   end_en_flag    <= 3'd0; 
//                end
//                else begin
//                   rd_data_reg   <= {rd_data_dly[1:0],rd_data_reg_0[1:0]};  
//                   rd_data_reg_0 <= 4'd0;
//                   insert_data    <= 4'd0;
//                   insert_data_en <= 1'b0;
//                   end_en         <= 1'b0;
//                   end_en_cnt     <= 3'd0;
//                   end_en_flag    <= 3'd0;
//                end
//             end
//             else if((ram_rd_data_dly[11:10] == 2'd1) || (ram_rd_data_dly[11:10] == 2'd2) ||(ram_rd_data_dly[11:10] == 2'd3))begin
//                if(detained_flag_reg_reg_reg_dly && detained_flag_reg_reg_dly )begin         //前一block 1    1
//                   rd_data_reg   <= rd_data_dly;   
//                   rd_data_reg_0 <= 4'd0;  
//                   insert_data    <= 4'd0;
//                   insert_data_en <= 1'b0;
//                   end_en         <= 1'b0;
//                   end_en_cnt     <= 3'd0;
//                   end_en_flag    <= 3'd0;                 
//                end
//                else if(detained_flag_reg_reg_reg_dly && !detained_flag_reg_reg_dly )begin   //前一block 1    0
//                   rd_data_reg   <= rd_data_dly;   
//                   rd_data_reg_0 <= 4'd0; 
//                   insert_data    <= 4'd0;
//                   insert_data_en <= 1'b0;
//                   end_en         <= 1'b0;
//                   end_en_cnt     <= 3'd0;
//                   end_en_flag    <= 3'd0;                  
//                end
//                else if(!detained_flag_reg_reg_reg_dly && detained_flag_reg_reg_dly )begin   //前一block 0    1
//                   rd_data_reg   <= {rd_data_dly[1:0],rd_data_reg_0[1:0]};   
//                   rd_data_reg_0 <= {2'd0,rd_data_dly[3:2]};  
//                   insert_data    <= 4'd0;
//                   insert_data_en <= 1'b0;
//                   end_en         <= 1'b0;
//                   end_en_cnt     <= 3'd0;
//                   end_en_flag    <= 3'd0;               
//                end
//                else if(!detained_flag_reg_reg_reg_dly && !detained_flag_reg_reg_dly )begin   //前一block 0    0
//                   rd_data_reg   <= {ram_rd_data_dly[1:0],rd_data_dly[1:0]};   
//                   rd_data_reg_0 <= {2'd0,rd_data_dly[3:2]};  
//                   insert_data    <= 4'd0;
//                   insert_data_en <= 1'b0;
//                   end_en         <= 1'b0;
//                   end_en_cnt     <= 3'd0;
//                   end_en_flag    <= 3'd0;                 
//                end
//             end
//          end     
//          else if((!fifo_rd_en_dly_0 & fifo_rd_en_dly_1) || (end_en))begin     //结尾
//             if((detained_flag_reg_dly_1 && detained_flag_reg_reg_dly_1) || (end_en_flag == 3'd1))begin   //当前block 1  1
//                   if(ram_rd_data[11:10] == 2'd0)begin
//                      rd_data_reg   <= {rd_data_dly[1:0],rd_data_reg_0[1:0]};   
//                      rd_data_reg_0 <= {2'd0,rd_data_dly[3:2]};  
//                      insert_data    <= 4'd0;
//                      insert_data_en <= 1'b0;
//                      end_en         <= 1'b0;
//                      end_en_cnt     <= 3'd0;
//                      end_en_flag    <= 3'd0;                    
//                   end
//                   else begin
//                      if(end_en_cnt == 3'd0)begin
//                         rd_data_reg   <= {rd_data_dly[1:0],rd_data_reg_0[1:0]};   
//                         rd_data_reg_0 <= {2'd0,rd_data_dly[3:2]}; 
//                         insert_data    <= 4'd0;
//                         insert_data_en <= 1'b0;
//                         end_en        <= 1'b1;
//                         end_en_cnt    <= end_en_cnt + 1'd1;
//                         end_en_flag   <= 3'd1;
//                      end
//                      else if(end_en_cnt == 3'd1)begin
//                         rd_data_reg   <= rd_data_reg  ;
//                         rd_data_reg_0 <= rd_data_reg_0;
//                         insert_data    <= {2'b10,ram_rd_data[11:10]};  
//                         insert_data_en <= 1'b1;
//                         end_en         <= 1'b1;
//                         end_en_cnt     <= end_en_cnt + 1'd1;
//                         end_en_flag    <= 3'd1;
//                      end
//                      else if(end_en_cnt == 3'd2)begin
//                         rd_data_reg   <= rd_data_reg  ;
//                         rd_data_reg_0 <= rd_data_reg_0;
//                         insert_data    <= {ram_rd_data[1:0],rd_data_reg_0[1:0]};  
//                         insert_data_en <= 1'b1;
//                         end_en         <= 1'b0;
//                         end_en_cnt     <= 3'd0;
//                         end_en_flag    <= 3'd0;
//                      end
//                   end
//             end
//             else if((detained_flag_reg_reg_dly_1 && !detained_flag_reg_dly_1) || (end_en_flag == 3'd2))begin   //当前block 1  0
//                   if(ram_rd_data[11:10] == 2'd0)begin
//                      rd_data_reg   <= {rd_data_dly[1:0],rd_data_reg_0[1:0]};   
//                      rd_data_reg_0 <= {2'd0,rd_data_dly[3:2]};  
//                      insert_data    <= 4'd0;
//                      insert_data_en <= 1'b0;
//                      end_en         <= 1'b0;
//                      end_en_cnt     <= 3'd0;
//                      end_en_flag    <= 3'd0;                     
//                   end
//                   else begin
//                      if(end_en_cnt == 3'd0)begin
//                         rd_data_reg   <= {rd_data_dly[1:0],rd_data_reg_0[1:0]};   
//                         rd_data_reg_0 <= {2'd0,rd_data_dly[3:2]}; 
//                         insert_data    <= 4'd0;
//                         insert_data_en <= 1'b0;
//                         end_en         <= 1'b1;
//                         end_en_cnt     <= end_en_cnt + 1'd1;
//                         end_en_flag    <= 3'd2;
//                      end
//                      else if(end_en_cnt == 3'd1)begin
//                         rd_data_reg   <= rd_data_reg  ;
//                         rd_data_reg_0 <= rd_data_reg_0;
//                         insert_data    <= {rd_data_reg_0[1:0],2'b10};  
//                         insert_data_en <= 1'b1;
//                         end_en         <= 1'b1;
//                         end_en_cnt     <= end_en_cnt + 1'd1;
//                         end_en_flag    <= 3'd2;
//                      end
//                      else if(end_en_cnt == 3'd2)begin
//                         rd_data_reg   <= rd_data_reg  ;
//                         rd_data_reg_0 <= rd_data_reg_0;
//                         insert_data    <= {ram_rd_data[11:10],ram_rd_data[1:0]};  
//                         insert_data_en <= 1'b1;
//                         end_en         <= 1'b0;
//                         end_en_cnt     <= 3'd0;
//                         end_en_flag    <= 3'd0;
//                      end
//                   end
//             end  
//             else if((!detained_flag_reg_reg_dly_1 && detained_flag_reg_dly_1) || (end_en_flag == 3'd3))begin   //当前block 0  1
//                   if(ram_rd_data[11:10] == 2'd0)begin
//                      rd_data_reg   <= rd_data_dly;   
//                      rd_data_reg_0 <= 4'd0; 
//                      insert_data    <= 4'd0;
//                      insert_data_en <= 1'b0;
//                      end_en         <= 1'b0;
//                      end_en_cnt     <= 3'd0;
//                      end_en_flag    <= 3'd0;                            
//                   end
//                   else begin
//                      if(end_en_cnt == 3'd0)begin
//                         rd_data_reg   <= {rd_data_dly[1:0],2'b10};   
//                         rd_data_reg_0 <= {2'd0,rd_data_dly[3:2]}; 
//                         insert_data    <= 4'd0;
//                         insert_data_en <= 1'b0;
//                         end_en         <= 1'b1;
//                         end_en_cnt     <= end_en_cnt + 1'd1;
//                         end_en_flag    <= 3'd3;
//                      end
//                      else if(end_en_cnt == 3'd1)begin
//                         rd_data_reg   <= rd_data_reg  ;
//                         rd_data_reg_0 <= rd_data_reg_0;
//                         insert_data    <= {ram_rd_data[11:10],ram_rd_data[1:0]};  
//                         insert_data_en <= 1'b1;
//                         end_en         <= 1'b0;
//                         end_en_cnt     <= 3'd0;
//                         end_en_flag    <= 3'd0;
//                      end
//                   end
//             end 
//             else if((!detained_flag_reg_reg_dly_1 && !detained_flag_reg_dly_1) || (end_en_flag == 3'd4))begin   //当前block 0  0
//                   if(ram_rd_data[11:10] == 2'd0)begin
//                      rd_data_reg   <= rd_data_dly;   
//                      rd_data_reg_0 <= 4'd0;  
//                      insert_data    <= 4'd0;
//                      insert_data_en <= 1'b0;
//                      end_en         <= 1'b0;
//                      end_en_cnt     <= 3'd0;
//                      end_en_flag    <= 3'd0;                      
//                   end
//                   else begin
//                      if(end_en_cnt == 3'd0)begin
//                         rd_data_reg   <= rd_data_dly;   
//                         rd_data_reg_0 <= 4'd0; 
//                         insert_data    <= 4'd0;
//                         insert_data_en <= 1'b0;
//                         end_en         <= 1'b1;
//                         end_en_cnt     <= end_en_cnt + 1'd1;
//                         end_en_flag    <= 3'd4;
//                      end
//                      else if(end_en_cnt == 3'd1)begin
//                         rd_data_reg   <= rd_data_reg  ;
//                         rd_data_reg_0 <= rd_data_reg_0;
//                         insert_data    <= {2'b10,ram_rd_data[11:10]};  
//                         insert_data_en <= 1'b1;
//                         end_en         <= 1'b0;
//                         end_en_cnt     <= 3'd0;
//                         end_en_flag    <= 3'd0;
//                      end
//                   end
//             end 
//          end      
//          else if(fifo_rd_en_dly_1)begin     //中间
//             if(detained_flag_reg_reg_dly)begin
//                rd_data_reg   <= {rd_data_dly[1:0],rd_data_reg_0[1:0]};   
//                rd_data_reg_0 <= {2'b00,rd_data_dly[1:0]};   
//                insert_data    <= 4'd0;
//                insert_data_en <= 1'b0;
//                end_en         <= 1'b0;
//                end_en_cnt     <= 3'd0;
//                end_en_flag    <= 3'd0;   
//             end 
//             else if(!detained_flag_reg_reg_dly)begin
//                rd_data_reg   <= rd_data_dly;   
//                rd_data_reg_0 <= 4'd0;
//                insert_data    <= 4'd0;
//                insert_data_en <= 1'b0;
//                end_en         <= 1'b0;
//                end_en_cnt     <= 3'd0;
//                end_en_flag    <= 3'd0; 
//             end 
//          end      
//       end
//       else begin
//          rd_data_reg   <= rd_data_reg;   
//          rd_data_reg_0 <= rd_data_reg_0;
//          insert_data    <= 4'd0;
//          insert_data_en <= 1'b0;
//          end_en         <= 1'b0;
//          end_en_cnt     <= 3'd0;
//          end_en_flag    <= 3'd0; 
//       end   
//     end

// wire empty_pc;
// wire wr_en_pc;
// reg rd_en_pc;
// reg rd_restriction_flag;
// wire [3:0] rd_data_to_pc;
// wire [3:0] wr_data_to_pc;
// assign  wr_en_pc = fifo_rd_en_dly_2 || insert_data_en;
// assign  wr_data_to_pc = fifo_rd_en_dly_2 ? rd_data_reg : insert_data;
//     always@(posedge clk) begin
//       if(reset|| newframe)begin
//          rd_en_pc <= 1'b0;      
//          rd_restriction_flag <= 1'b0;  
//       end
//       else if(fifo_rd_en_dly_3 & !fifo_rd_en_dly_2)begin
//          rd_en_pc <= rd_en_pc;      
//          rd_restriction_flag <= 1'b0;  
//       end
//       // else if(fifo_rd_en_cnt_all == 11'd0)begin
//       //    rd_en_pc <= rd_en_pc;      
//       //    rd_restriction_flag <= 1'b0; 
//       // end
//       else if((fifo_rd_en_cnt_all == fifo_wr_en_cnt_reg ) && (!rd_restriction_flag))begin
//          rd_en_pc <= 1'b1;      
//          rd_restriction_flag <= 1'b1; 
//       end
//       else if(empty_pc)begin
//          rd_en_pc <= 1'b0;   
//          rd_restriction_flag <= 1'b1; 
//       end
//       else begin
//          rd_en_pc <= rd_en_pc;      
//          rd_restriction_flag <= rd_restriction_flag;  
//       end

//     end
// /************ 最终向上位机传输的压缩数据****************/
// compression_data_to_pc compression_data_to_pc(
//     // Inputs
//     .CLK       (clk),
//     .DATA      (wr_data_to_pc),      // [3:0]
//     .RE        (rd_en_pc),
//     .RESET_N   (!newframe),
//     .WE        (wr_en_pc),
//     // Outputs
//     .EMPTY     (empty_pc),
//     .FULL      (),
//     .Q         (rd_data_to_pc),         // [3:0]
//     .RDCNT     ()                       // [10:0]
// );
endmodule