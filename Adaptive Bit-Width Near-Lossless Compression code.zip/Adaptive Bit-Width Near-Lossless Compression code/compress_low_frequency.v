module compress_low_frequency#(
    parameter DATA_WIDTH         = 14,
    parameter LINE_WIDTH         = 12,
    parameter PIX_WIDTH          = 12,
    parameter TAPS               = 4
)
(
    input                            clk,
    input                            sensor_clk_x4,
    input       [LINE_WIDTH-1:0]     LINE ,   //行数
    input       [PIX_WIDTH-1:0]      PIX ,    //每行的像素数
    input                            reset,
    input                            newframe,
    input                            line1_buf_valid5_even,    //下降之后开始低频数据压缩差值
    input                            data_dvalid_A,
    input        [7 : 0]             data_A,                
    input        [11 : 0]            deviation_cg_wr_addr_reg,
    input                            reference_flag,
    input        [7 : 0]             Reference_pixel,
    input                            deviation_cnt_reg_en,
    input        [11 : 0]            deviation_cnt_reg,
    input                            deviation_wr_en,
    input                            negative_flag,   //差值的符号
    input        [7 : 0]             deviation,
    input                            deviation_dvalid,
    input                            fifo_insert_done_all,
    input                            frequency_rd_flag,


    output  reg         fifo_insert_done,
    output  reg [7:0]   data_out,
    output  reg         data_lv

);

reg  line1_buf_valid5_even_d0;
reg  line1_buf_valid5_even_d1;
reg  line1_buf_valid5_even_d2;
reg  line1_buf_valid5_even_d3;
reg  line1_buf_valid5_even_d4;
reg  line1_buf_valid5_even_d5;
reg  line1_buf_valid5_even_d6;
reg  line1_buf_valid5_even_d7;
reg  line1_buf_valid5_even_d8;
reg  line1_buf_valid5_even_d9;
reg  line1_buf_valid5_even_d10;
reg  line1_buf_valid5_even_d11;
reg  line1_buf_valid5_even_d12;


  always@(posedge sensor_clk_x4)begin
     line1_buf_valid5_even_d0 <= line1_buf_valid5_even;
     line1_buf_valid5_even_d1 <= line1_buf_valid5_even_d0;
     line1_buf_valid5_even_d2 <= line1_buf_valid5_even_d1;   
     line1_buf_valid5_even_d3 <= line1_buf_valid5_even_d2;
     line1_buf_valid5_even_d4 <= line1_buf_valid5_even_d3;
     line1_buf_valid5_even_d5 <= line1_buf_valid5_even_d4;
     line1_buf_valid5_even_d6 <= line1_buf_valid5_even_d5;
     line1_buf_valid5_even_d7 <= line1_buf_valid5_even_d6;
     line1_buf_valid5_even_d8 <= line1_buf_valid5_even_d7;
     line1_buf_valid5_even_d9 <= line1_buf_valid5_even_d8;
     line1_buf_valid5_even_d10 <= line1_buf_valid5_even_d9;
     line1_buf_valid5_even_d11 <= line1_buf_valid5_even_d10;
     line1_buf_valid5_even_d12 <= line1_buf_valid5_even_d11;
  end

reg  deviation_fifo_rd;
reg  deviation_cnt_reg_fifo_rd;
reg  Reference_pixel_fifo_rd;
reg  [3:0]  deviation_data_rd;
reg  [11:0] deviation_cnt_reg_data_rd;
reg  [7:0]  Reference_pixel_data_rd;
reg  deviation_fifo_EMPTY;
reg  deviation_cnt_reg_fifo_EMPTY;
reg  Reference_pixel_fifo_EMPTY;

    deviation_fifo deviation_fifo(        //相邻像素的差值
        // Inputs
        .DATA       ({negative_flag,deviation[2:0]}),   //[3:0] 
        .RCLOCK     (sensor_clk_x4),
        .RE         (deviation_fifo_rd),
        .RRESET_N   (!newframe),
        .WCLOCK     (clk),
        .WE         (deviation_wr_en),
        .WRESET_N   (!newframe),
        // Outputs
        .EMPTY      (deviation_fifo_EMPTY),
        .FULL       (),
        .Q          (deviation_data_rd),       //[3:0] 
        .RDCNT      ()    //[10:0]
    );

    deviation_cnt_reg_fifo deviation_cnt_reg_fifo(    //连续差值小于 8 的差值数量
        // Inputs
        .DATA       (deviation_cnt_reg),  //[11:0]
        .RCLOCK     (sensor_clk_x4),
        .RE         (deviation_cnt_reg_fifo_rd),
        .RRESET_N   (!newframe),
        .WCLOCK     (clk),
        .WE         (deviation_cnt_reg_en),
        .WRESET_N   (!newframe),
        // Outputs
        .EMPTY      (deviation_cnt_reg_fifo_EMPTY),
        .FULL       (),
        .Q          (deviation_cnt_reg_data_rd),    //[11:0]
        .RDCNT      () //[10:0]
    );

    Reference_pixel_fifo Reference_pixel_fifo(     //参考像素
        // Inputs
        .DATA       (Reference_pixel),  //[7:0]
        .RCLOCK     (sensor_clk_x4),
        .RE         (Reference_pixel_fifo_rd),
        .RRESET_N   (!newframe),
        .WCLOCK     (clk),
        .WE         (reference_flag),
        .WRESET_N   (!newframe),
        // Outputs
        .EMPTY      (Reference_pixel_fifo_EMPTY),
        .FULL       (),
        .Q          (Reference_pixel_data_rd),   //[7:0]
        .RDCNT      ()  //[10:0]
    );

/******************** 低频数据压缩包整合的状态机 ***********************/
localparam	s_IDLE			        =	'd0,
		    s_reference_insert      =	'd1,
		    s_deviation_insert      =	'd2,
		    s_dev_nummber_insert    =	'd3,
            s_reference_rd          =	'd4,
            s_dev_nummber_rd        =   'd5,
            s_deviation_rd          =	'd6,
		    s_FINAL	                =	'd11;

reg   [3:0] fsm_process;
reg         low_compress_wr;
reg   [3:0] low_compress_wr_data;
reg   [11:0] insert_cnt;
reg   [11:0] deviation_addr_cnt;

      always@(posedge sensor_clk_x4)begin
          if(reset || newframe)begin
            fsm_process             <= s_IDLE;
            Reference_pixel_fifo_rd <= 1'b0;
            insert_cnt              <= 12'd0;
            low_compress_wr_data    <= 3'd0;
            low_compress_wr         <= 1'b0;
            deviation_addr_cnt      <= 12'd0;
            deviation_fifo_rd         <= 1'b0;
            deviation_cnt_reg_fifo_rd <= 1'b0;
          end
          else if(line1_buf_valid5_even_d8 && !line1_buf_valid5_even_d7)begin    //插入每行低频压缩之后的数据块总数量
            low_compress_wr_data    <= {2'd0,deviation_cg_wr_addr_reg[9:8]};
            low_compress_wr         <= 1'b1;
          end
          else if(line1_buf_valid5_even_d9 && !line1_buf_valid5_even_d8)begin    //插入每行低频压缩之后的数据块总数量
            low_compress_wr_data    <= deviation_cg_wr_addr_reg[7:4];
            low_compress_wr         <= 1'b1;
          end
          else if(line1_buf_valid5_even_d10 && !line1_buf_valid5_even_d9)begin    //插入每行低频压缩之后的数据块总数量
            low_compress_wr_data    <= deviation_cg_wr_addr_reg[3:0];
            low_compress_wr         <= 1'b1;
          end
          else begin
                case(fsm_process)
                      s_IDLE:begin
                          if(line1_buf_valid5_even_d12 && !line1_buf_valid5_even_d11)begin
                              fsm_process             <= s_reference_rd;
                              low_compress_wr_data    <= low_compress_wr_data;
                              low_compress_wr         <= 1'b0;
                          end
                          else begin
                              fsm_process             <= s_IDLE;
                              low_compress_wr_data    <= low_compress_wr_data;
                              low_compress_wr         <= 1'b0;
                          end  
                      end
                      s_reference_rd:begin      //读取参考像素
                            if(deviation_addr_cnt == deviation_cg_wr_addr_reg)begin
                                  deviation_addr_cnt <= 12'd0;
                                  fsm_process  <= s_IDLE;
                            end
                            else begin
                                  Reference_pixel_fifo_rd <= 1'b1;   //拉高之后，延迟一个时钟周期读出参考像素
                                  fsm_process  <= s_reference_insert;
                            end
                      end			
                      s_reference_insert:begin 
                            if(insert_cnt == 12'd2)begin
                                  low_compress_wr         <= 1'b1;
                                  low_compress_wr_data    <= Reference_pixel_data_rd[7:4];
                                  insert_cnt <= insert_cnt + 1'd1;
                            end
                            else if(insert_cnt == 12'd3)begin
                                  low_compress_wr         <= 1'b1;
                                  low_compress_wr_data    <= Reference_pixel_data_rd[3:0];
                                  insert_cnt              <= 12'd0;
                                  fsm_process             <= s_dev_nummber_rd;
                            end
                            else begin
                                  insert_cnt              <= insert_cnt + 1'd1;
                                  Reference_pixel_fifo_rd <= 1'b0; 
                            end     
                      end
                      s_dev_nummber_rd:begin   //读取连续 <8 差值块数量
                            low_compress_wr           <= 1'b0;
                            deviation_cnt_reg_fifo_rd <= 1'b1;
                            fsm_process               <= s_dev_nummber_insert;
                      end	
                      s_dev_nummber_insert:begin
                            if(insert_cnt == 12'd2)begin
                                  low_compress_wr         <= 1'b1;
                                  low_compress_wr_data    <= deviation_cnt_reg_data_rd[11:8];
                                  insert_cnt <= insert_cnt + 1'd1;
                            end
                            else if(insert_cnt == 12'd3)begin
                                  low_compress_wr         <= 1'b1;
                                  low_compress_wr_data    <= deviation_cnt_reg_data_rd[7:4];
                                  insert_cnt <= insert_cnt + 1'd1;
                            end
                            else if(insert_cnt == 12'd4)begin
                                  low_compress_wr         <= 1'b1;
                                  low_compress_wr_data    <= deviation_cnt_reg_data_rd[3:0];
                                  insert_cnt              <= 12'd0;
                                  fsm_process             <= s_deviation_rd;
                            end
                            else begin
                                  insert_cnt              <= insert_cnt + 1'd1;
                                  deviation_cnt_reg_fifo_rd <= 1'b0; 
                            end     
                      end
                      s_deviation_rd:begin      //读取差值信息
                          low_compress_wr     <= 1'b0;
                          deviation_fifo_rd   <= (deviation_cnt_reg_data_rd == 12'd0) ? 1'b0:1'b1;
                          fsm_process         <= s_deviation_insert;
                      end
                      s_deviation_insert:begin
                            if(deviation_cnt_reg_data_rd > 12'd0)begin
                                  if(insert_cnt == deviation_cnt_reg_data_rd + 12'd2)begin
                                      fsm_process       <= s_reference_rd; 
                                      insert_cnt        <= 12'd0;
                                      low_compress_wr   <= 1'b0; 
                                      deviation_addr_cnt <= deviation_addr_cnt + 1'b1;
                                  end
                                  else begin
                                        insert_cnt              <= insert_cnt + 1'd1;
                                        deviation_fifo_rd       <= (insert_cnt == deviation_cnt_reg_data_rd - 12'd1) ? 1'b0 : deviation_fifo_rd;
                                        low_compress_wr_data    <= (insert_cnt >= 12'd2) ? deviation_data_rd : low_compress_wr_data;
                                        low_compress_wr         <= (insert_cnt >= 12'd2) ? 1'b1 : low_compress_wr;
                                  end                                
                            end
                            else if(deviation_cnt_reg_data_rd == 12'd0)begin
                                      deviation_fifo_rd <=  1'b0;
                                      fsm_process       <= s_reference_rd; 
                                      insert_cnt        <= 12'd0;
                                      low_compress_wr   <= 1'b0; 
                                      deviation_addr_cnt <= deviation_addr_cnt + 1'b1;                          
                            end
                      end
                      default: begin 
                          fsm_process <= s_IDLE; 
                      end
                endcase
          end
      end

reg       low_compress_data_rd;
reg [7:0] low_compress_data;
reg       low_compress_data_fifo_EMPTY;
low_compress_data_fifo low_compress_data_fifo(
    // Inputs
    .DATA         (low_compress_wr_data),  //[3:0]
    .RCLOCK       (sensor_clk_x4),
    .RE           (low_compress_data_rd),
    .RRESET_N     (!newframe),
    .WCLOCK       (sensor_clk_x4),
    .WE           (low_compress_wr || low_compress_wr_monitor),
    .WRESET_N     (!newframe),
    // Outputs
    .EMPTY        (low_compress_data_fifo_EMPTY),
    .FULL         (),
    .Q            (low_compress_data),   //[7:0]
    .RDCNT        ()    //[9:0]
);

reg  low_compress_wr_monitor;   
reg  [3:0] monitor_cnt;
reg  [3:0] wr_en_cnt;
//************ 解决以4bit写入fifo，以8bit读出，写入的bit数不是8bit的倍数
always@(posedge sensor_clk_x4)begin
    if(reset || newframe)
        monitor_cnt        <= 4'd2;
    else if(line1_buf_valid5_even_d0 && !line1_buf_valid5_even)
        monitor_cnt        <= 4'd2;
    else if(low_compress_wr)begin
        if(monitor_cnt == 4'd0)
            monitor_cnt <= 4'd1;
        else
            monitor_cnt <= monitor_cnt - 4'd1;
    end
    else
        monitor_cnt  <= monitor_cnt;
end

always@(posedge sensor_clk_x4)begin
    if(reset || newframe)begin
        low_compress_wr_monitor  <= 4'd0;
        wr_en_cnt           <= 4'd0;
    end
    else if(line1_buf_valid5_even_d0 && !line1_buf_valid5_even)begin
        low_compress_wr_monitor  <= 4'd0; 
        wr_en_cnt           <= 4'd0;   
    end
    else if(low_compress_data_rd)begin   
        if(monitor_cnt == wr_en_cnt)begin
            low_compress_wr_monitor  <= 4'd0;    
            wr_en_cnt           <= wr_en_cnt;     
        end
        else begin
            low_compress_wr_monitor  <= 4'd1;    
            wr_en_cnt           <= wr_en_cnt + 4'd1;   
        end
    end
    else begin
        low_compress_wr_monitor  <= low_compress_wr_monitor; 
        wr_en_cnt           <= wr_en_cnt         ;      
    end
end

//*********** 压缩数据存储完成信号，并等待所有频域的数据都压缩完成
always@(posedge sensor_clk_x4)begin
    if(reset || newframe)
        fifo_insert_done <= 1'b0;
    else if((deviation_addr_cnt == deviation_cg_wr_addr_reg) && (deviation_addr_cnt != 11'd0))
        fifo_insert_done <= 1'b1;
    else if(fifo_insert_done_all)
        fifo_insert_done <= 1'b0;
    else
        fifo_insert_done <= fifo_insert_done;
end

always@(posedge sensor_clk_x4)begin
   if(reset || newframe)
      low_compress_data_rd <= 1'b0;
   else if(frequency_rd_flag && !frequency_rd_flag_d)//    else if(deviation_addr_cnt == deviation_cg_wr_addr_reg)
      low_compress_data_rd <= 1'b1;
   else if(low_compress_data_fifo_EMPTY)
      low_compress_data_rd <= 1'b0;
   else
      low_compress_data_rd <= low_compress_data_rd;
end

reg frequency_rd_flag_d;
reg low_compress_data_rd_d0;
reg low_compress_data_rd_d1;
always@(posedge sensor_clk_x4)begin
      frequency_rd_flag_d <= frequency_rd_flag;    
      low_compress_data_rd_d0 <= low_compress_data_rd;
      low_compress_data_rd_d1 <= low_compress_data_rd_d0;
      data_out    <= {low_compress_data[3:0],low_compress_data[7:4]};//low_compress_data;
      data_lv     <= low_compress_data_rd_d0 && low_compress_data_rd_d1;
  end

endmodule