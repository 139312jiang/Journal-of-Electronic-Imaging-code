module freq_data_convert#(
    parameter DATA_WIDTH         = 14,
    parameter LINE_WIDTH         = 12,
    parameter PIX_WIDTH          = 12,
    parameter TAPS               = 4
)
(
    input                            clk,
    input                            sensor_clk_x4,
    input       [LINE_WIDTH-1:0]     LINE ,   //行数
    input       [PIX_WIDTH-1:0]      PIX ,    //每行的像素数
    input                            reset,
    input                            newframe,
    
    input      [ 1 :0]               bit_flag,
    input                            negative_sign,
    input   [DATA_WIDTH*TAPS - 1 :0] data,
    input                            pix_vaild,       //每个像素的有效指示信号
    input                            data_valid,
    input                            fifo_insert_done_all,
    input                            frequency_rd_flag,

    output                           fifo_insert_done,       
    output  [7 :0]                   data_out,       //  rgb data
    output                           data_out_valid

);
wire  [10:0] RDCNT;
reg   [7:0] data_wr;
reg   data_valid_d0;
reg   data_valid_d1;
reg   data_valid_d2;
reg   data_valid_d3;
reg   [1:0] bit_flag_d;
reg   [1:0] bit_flag_d0;
reg   pix_vaild_d ;
reg   [11:0] pix_vaild_cnt;    //l一行下的有效像素计数

// clk 时钟域下的延时
always@(posedge clk)begin
    if(reset || newframe)begin
        data_wr <= 12'd0;
        data_valid_d0 <= 1'b0;
        data_valid_d1 <= 1'b0;
        data_valid_d2 <= 1'b0;
        data_valid_d3 <= 1'b0;
        pix_vaild_d  <= 1'b0;
        bit_flag_d   <= 2'd0;
        bit_flag_d0  <= 2'd0;
    end
    else begin
        // data_wr <= {negative_sign,data[6:0]};//data;//{1'b0,negative_sign,bit_flag,data};  高频最大值为127
        case(bit_flag)
            2'd0: data_wr <= {negative_sign, data[0],6'd0};  //{6'd0, negative_sign, data[0]};       // 2bit: sign + 1bit magnitude
            2'd1: data_wr <= {negative_sign, data[2:0],4'd0};//{4'd0, negative_sign, data[2:0]};     // 4bit: sign + 3bit magnitude
            2'd2: data_wr <= {negative_sign, data[4:0],2'd0};//{2'd0, negative_sign, data[4:0]};     // 6bit: sign + 5bit magnitude
            2'd3: data_wr <= {negative_sign, data[6:0]};      //{negative_sign, data[6:0]};           // 8bit: sign + 7bit magnitude
        endcase
        data_valid_d0 <= data_valid;
        data_valid_d1 <= data_valid_d0;
        data_valid_d2 <= data_valid_d1;
        data_valid_d3 <= data_valid_d2;

        pix_vaild_d  <= pix_vaild;
        bit_flag_d   <= bit_flag;
        bit_flag_d0  <= bit_flag_d;
    end
  end
  always@(posedge clk)begin
    if(reset || newframe)
        pix_vaild_cnt <= 12'd0;
    else if(data_valid)begin
        if(pix_vaild)
            pix_vaild_cnt <= pix_vaild_cnt + 1'b1;
        else
            pix_vaild_cnt <= pix_vaild_cnt;
    end
    else
        pix_vaild_cnt <= 12'd0;
  end
reg   data_valid_x4_d0;
reg   data_valid_x4_d1;
reg   data_valid_x4_d2;
reg   data_valid_x4_d3;
reg   data_valid_x4_d4;
// sensor_clk_x4 时钟域下的延时
always@(posedge sensor_clk_x4)begin
    if(reset || newframe)begin
        data_valid_x4_d0  <= 1'b0;
        data_valid_x4_d1 <= 1'b0;
        data_valid_x4_d2 <= 1'b0;
        data_valid_x4_d3 <= 1'b0;
        data_valid_x4_d4 <= 1'b0;
    end
    else begin
        data_valid_x4_d0  <= data_valid;
        data_valid_x4_d1 <= data_valid_x4_d0;
        data_valid_x4_d2 <= data_valid_x4_d1;
        data_valid_x4_d3 <= data_valid_x4_d2;
        data_valid_x4_d4 <= data_valid_x4_d3;
    end
  end

wire [7:0] data_rd;
wire   rd_en;
freq_convert_fifo freq_convert_fifo(
    // Inputs
    .DATA       (data_wr),   // [7:0]
    .RCLOCK     (sensor_clk_x4),
    .RE         (rd_en),
    .RRESET_N   (!newframe),
    .WCLOCK     (clk),
    .WE         (data_valid_d0 && pix_vaild_d),
    .WRESET_N   (!newframe),
    // Outputs
    .EMPTY      (),
    .FULL       (),
    .Q          (data_rd ),// [7:0]
    .RDCNT      (RDCNT) //[10:0]
);

/********************** 记录一行中的2bit数据的个数还有4bit、6bit、8bit的连续数量，并将块信息存入RAM *********************/
/*********************************** 4bit、6bit、8bit连续数量最大为4 *******************************/
reg [10:0] lint_2bit_cnt;
reg [10:0] lint_2bit_cnt_reg;
reg [9:0]  block_2bit_cnt;
reg [2:0]  block_4bit_cnt;
reg [2:0]  block_6bit_cnt;
reg [2:0]  block_8bit_cnt;
reg [10:0] ram_wr_addr;
reg [10:0] ram_wr_addr_reg;
reg        ram_wr_en;
reg  [9:0] ram_wr_data;   //记录块的大小
  always@(posedge clk)begin
    if(reset || newframe)begin
        lint_2bit_cnt       <= 11'd0;
        lint_2bit_cnt_reg   <= 11'd0;
        block_2bit_cnt      <= 10'd0;
        block_4bit_cnt      <= 3'd0;
        block_6bit_cnt      <= 3'd0;
        block_8bit_cnt      <= 3'd0;
        ram_wr_addr         <= 11'd0;
        ram_wr_addr_reg     <= 11'd0;
        ram_wr_en           <= 1'd0;
        ram_wr_data         <= 10'd0;
    end
    else if(pix_vaild && data_valid)begin
        if(bit_flag == 2'd0)begin     //2bit
            if(block_4bit_cnt != 3'd0)begin    //从4bit转到2bit
                lint_2bit_cnt       <= lint_2bit_cnt + 1'b1;
                lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                block_2bit_cnt      <= block_2bit_cnt + 1'b1;
                block_4bit_cnt      <= 3'd0;
                block_6bit_cnt      <= 3'd0;
                block_8bit_cnt      <= 3'd0;
                ram_wr_addr         <= ram_wr_addr + 1'b1;
                ram_wr_addr_reg     <= ram_wr_addr_reg;
                ram_wr_en           <= 1'd1;
                ram_wr_data         <= block_4bit_cnt;
            end
            else if(block_6bit_cnt != 3'd0)begin //从6bit转到2bit
                lint_2bit_cnt       <= lint_2bit_cnt + 1'b1;
                lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                block_2bit_cnt      <= block_2bit_cnt + 1'b1;
                block_4bit_cnt      <= 3'd0;
                block_6bit_cnt      <= 3'd0;
                block_8bit_cnt      <= 3'd0;
                ram_wr_addr         <= ram_wr_addr + 1'b1;
                ram_wr_addr_reg     <= ram_wr_addr_reg;
                ram_wr_en           <= 1'd1;
                ram_wr_data         <= block_6bit_cnt;
            end
            else if(block_8bit_cnt != 3'd0)begin  //从8bit转到2bit
                lint_2bit_cnt       <= lint_2bit_cnt + 1'b1;
                lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                block_2bit_cnt      <= block_2bit_cnt + 1'b1;
                block_4bit_cnt      <= 3'd0;
                block_6bit_cnt      <= 3'd0;
                block_8bit_cnt      <= 3'd0;
                ram_wr_addr         <= ram_wr_addr + 1'b1;
                ram_wr_addr_reg     <= ram_wr_addr_reg;
                ram_wr_en           <= 1'd1;
                ram_wr_data         <= block_8bit_cnt;
            end
            else begin                          //2bit块递增
                lint_2bit_cnt       <= lint_2bit_cnt + 1'b1;
                lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                block_2bit_cnt      <= block_2bit_cnt + 1'b1;
                block_4bit_cnt      <= 3'd0;
                block_6bit_cnt      <= 3'd0;
                block_8bit_cnt      <= 3'd0;
                ram_wr_addr         <= ram_wr_addr;
                ram_wr_addr_reg     <= ram_wr_addr_reg;
                ram_wr_en           <= 1'd0;
                ram_wr_data         <= ram_wr_data;
            end
        end
        else if(bit_flag == 2'd1)begin     //4bit
            if(block_4bit_cnt == 3'd4)begin
                lint_2bit_cnt       <= lint_2bit_cnt;
                lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                block_2bit_cnt      <= 10'd0;
                block_4bit_cnt      <= 3'd1;
                block_6bit_cnt      <= 3'd0;
                block_8bit_cnt      <= 3'd0;
                ram_wr_addr         <= ram_wr_addr + 1'b1;
                ram_wr_addr_reg     <= ram_wr_addr_reg;
                ram_wr_en           <= 1'd1;
                ram_wr_data         <= block_4bit_cnt;
            end
            else begin
                if(block_4bit_cnt == 3'd0)begin
                    if(block_6bit_cnt != 3'd0)begin      //从6bit块转到4bit块
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <= block_4bit_cnt +1'b1;
                        block_6bit_cnt      <=  3'd0;
                        block_8bit_cnt      <=  3'd0;
                        ram_wr_addr         <= ram_wr_addr + 1'b1;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd1;
                        ram_wr_data         <= block_6bit_cnt;
                    end
                    else if(block_8bit_cnt != 3'd0)begin//从8bit块转到4bit块
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <= block_4bit_cnt +1'b1;
                        block_6bit_cnt      <=  3'd0;
                        block_8bit_cnt      <=  3'd0;
                        ram_wr_addr         <= ram_wr_addr + 1'b1;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd1;
                        ram_wr_data         <= block_8bit_cnt;
                    end
                    else if(block_2bit_cnt != 3'd0)begin                         //从2bit转到4bit
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <= block_4bit_cnt +1'b1;
                        block_6bit_cnt      <=  3'd0;
                        block_8bit_cnt      <=  3'd0;
                        ram_wr_addr         <= ram_wr_addr + 1'b1;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd1;
                        ram_wr_data         <= block_2bit_cnt;
                    end
                    else begin   //块内递增
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <= block_4bit_cnt + 1'b1;
                        block_6bit_cnt      <= 3'd0;
                        block_8bit_cnt      <= 3'd0;
                        ram_wr_addr         <= ram_wr_addr ;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd0;
                        ram_wr_data         <= ram_wr_data;
                    end                    
                end
                else begin                         //块内递增
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <= block_4bit_cnt +1'b1;
                        block_6bit_cnt      <=  3'd0;
                        block_8bit_cnt      <=  3'd0;
                        ram_wr_addr         <= ram_wr_addr ;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd0;
                        ram_wr_data         <= ram_wr_data;
                    end
            end    
        end
        else if(bit_flag == 2'd2)begin     //6bit
            if(block_6bit_cnt == 3'd4)begin
                lint_2bit_cnt       <= lint_2bit_cnt;
                lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                block_2bit_cnt      <= 10'd0;
                block_4bit_cnt      <= 3'd0;
                block_6bit_cnt      <=  3'd1;
                block_8bit_cnt      <=  3'd0;
                ram_wr_addr         <= ram_wr_addr + 1'b1;
                ram_wr_addr_reg     <= ram_wr_addr_reg;
                ram_wr_en           <= 1'd1;
                ram_wr_data         <= block_6bit_cnt;
            end
            else begin
                if(block_6bit_cnt == 3'd0)begin
                    if(block_4bit_cnt != 3'd0)begin      //从4bit块转到6bit块
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <=  3'd0;
                        block_6bit_cnt      <=  block_6bit_cnt + 1'b1;
                        block_8bit_cnt      <=  3'd0;
                        ram_wr_addr         <= ram_wr_addr + 1'b1;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd1;
                        ram_wr_data         <= block_4bit_cnt;
                    end
                    else if(block_8bit_cnt != 3'd0)begin//从8bit块转到6bit块
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <= 3'd0;
                        block_6bit_cnt      <= block_6bit_cnt + 1'b1;
                        block_8bit_cnt      <= 3'd0;
                        ram_wr_addr         <= ram_wr_addr + 1'b1;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd1;
                        ram_wr_data         <= block_8bit_cnt;
                    end
                    else if(block_2bit_cnt != 3'd0)begin                         //从2bit转到6bit
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <= 3'd0;
                        block_6bit_cnt      <= block_6bit_cnt + 1'b1;
                        block_8bit_cnt      <=  3'd0;
                        ram_wr_addr         <= ram_wr_addr + 1'b1;
                        ram_wr_addr_reg     <= ram_wr_addr_reg ;
                        ram_wr_en           <= 1'd1;
                        ram_wr_data         <= block_2bit_cnt;
                    end
                    else begin
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <= 3'd0;
                        block_6bit_cnt      <=  block_6bit_cnt + 1'b1;
                        block_8bit_cnt      <=  3'd0;
                        ram_wr_addr         <= ram_wr_addr;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd0;
                        ram_wr_data         <= ram_wr_data;
                    end
                end
                else begin                         //块内递增
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <= 3'd0;
                        block_6bit_cnt      <=  block_6bit_cnt + 1'b1;
                        block_8bit_cnt      <=  3'd0;
                        ram_wr_addr         <= ram_wr_addr;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd0;
                        ram_wr_data         <= ram_wr_data;
                    end
            end    
        end
        else if(bit_flag == 2'd3)begin     //8bit
            if(block_8bit_cnt == 3'd4)begin
                lint_2bit_cnt       <= lint_2bit_cnt;
                lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                block_2bit_cnt      <= 10'd0;
                block_4bit_cnt      <=  3'd0;
                block_6bit_cnt      <=  3'd0;
                block_8bit_cnt      <=  3'd0;
                ram_wr_addr         <= ram_wr_addr + 1'b1;
                ram_wr_addr_reg     <= ram_wr_addr_reg;
                ram_wr_en           <= 1'd1;
                ram_wr_data         <= block_8bit_cnt;
            end
            else begin
                if(block_8bit_cnt == 3'd0)begin
                    if(block_4bit_cnt != 3'd0)begin      //从4bit块转到8bit块
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <=  3'd0;
                        block_6bit_cnt      <=  3'd0;
                        block_8bit_cnt      <=  block_8bit_cnt + 1'b1;
                        ram_wr_addr         <= ram_wr_addr + 1'b1;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd1;
                        ram_wr_data         <= block_4bit_cnt;
                    end
                    else if(block_6bit_cnt != 3'd0)begin//从6bit块转到8bit块
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <= 3'd0;
                        block_6bit_cnt      <= 3'd0;
                        block_8bit_cnt      <= block_8bit_cnt + 1'b1;
                        ram_wr_addr         <= ram_wr_addr + 1'b1;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd1;
                        ram_wr_data         <= block_6bit_cnt;
                    end
                    else if(block_2bit_cnt != 3'd0)begin                         //从2bit转到8bit
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <= 3'd0;
                        block_6bit_cnt      <= 3'd0;
                        block_8bit_cnt      <= block_8bit_cnt + 1'b1;
                        ram_wr_addr         <= ram_wr_addr + 1'b1;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd1;
                        ram_wr_data         <= block_2bit_cnt;
                    end
                    else begin
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <= 3'd0;
                        block_6bit_cnt      <= 3'd0;
                        block_8bit_cnt      <= block_8bit_cnt + 1'b1;
                        ram_wr_addr         <= ram_wr_addr;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd0;
                        ram_wr_data         <= ram_wr_data;
                    end
                end
                else begin                         //块内递增
                        lint_2bit_cnt       <= lint_2bit_cnt;
                        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
                        block_2bit_cnt      <= 10'd0;
                        block_4bit_cnt      <= 3'd0;
                        block_6bit_cnt      <= 3'd0;
                        block_8bit_cnt      <= block_8bit_cnt + 1'b1;
                        ram_wr_addr         <= ram_wr_addr;
                        ram_wr_addr_reg     <= ram_wr_addr_reg;
                        ram_wr_en           <= 1'd0;
                        ram_wr_data         <= ram_wr_data;
                    end
            end    
        end
    end
    else if(data_valid_d0 && !data_valid)begin  //一行的最后一个数据判断
        if(block_4bit_cnt != 3'd0)begin      //最后一个块是4bit
            lint_2bit_cnt       <= lint_2bit_cnt;
            lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
            block_2bit_cnt      <= 10'd0;
            block_4bit_cnt      <=  3'd0;
            block_6bit_cnt      <=  3'd0;
            block_8bit_cnt      <=  3'd0;;
            ram_wr_addr         <= ram_wr_addr + 1'b1;
            ram_wr_addr_reg     <= ram_wr_addr_reg;
            ram_wr_en           <= 1'd1;
            ram_wr_data         <= block_4bit_cnt;
        end
        else if(block_6bit_cnt != 3'd0)begin//最后一个块是6bit
            lint_2bit_cnt       <= lint_2bit_cnt;
            lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
            block_2bit_cnt      <= 10'd0;
            block_4bit_cnt      <= 3'd0;
            block_6bit_cnt      <= 3'd0;
            block_8bit_cnt      <= 3'd0;
            ram_wr_addr         <= ram_wr_addr + 1'b1;
            ram_wr_addr_reg     <= ram_wr_addr_reg;
            ram_wr_en           <= 1'd1;
            ram_wr_data         <= block_6bit_cnt;
        end
        else if(block_8bit_cnt != 3'd0)begin//最后一个块是8bit
            lint_2bit_cnt       <= lint_2bit_cnt;
            lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
            block_2bit_cnt      <= 10'd0;
            block_4bit_cnt      <= 3'd0;
            block_6bit_cnt      <= 3'd0;
            block_8bit_cnt      <= 3'd0;
            ram_wr_addr         <= ram_wr_addr + 1'b1;
            ram_wr_addr_reg     <= ram_wr_addr_reg;
            ram_wr_en           <= 1'd1;
            ram_wr_data         <= block_8bit_cnt;
        end
        else  begin //最后以2bit结尾
            lint_2bit_cnt       <= lint_2bit_cnt;
            lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
            block_2bit_cnt      <= 10'd0;
            block_4bit_cnt      <= 3'd0;
            block_6bit_cnt      <= 3'd0;
            block_8bit_cnt      <= 3'd0;
            ram_wr_addr         <= ram_wr_addr + 1'b1;
            ram_wr_addr_reg     <= ram_wr_addr_reg;
            ram_wr_en           <= 1'd1;
            ram_wr_data         <= block_2bit_cnt;
        end                     
    end
    else if(data_valid_d1 && !data_valid_d0)begin  //一行统计结束
        lint_2bit_cnt       <= 11'd0;
        lint_2bit_cnt_reg   <= lint_2bit_cnt;
        block_2bit_cnt      <= 10'd0;
        block_4bit_cnt      <= 3'd0;
        block_6bit_cnt      <= 3'd0;
        block_8bit_cnt      <= 3'd0;
        ram_wr_addr         <= 11'd0;
        ram_wr_addr_reg     <= ram_wr_addr;
        ram_wr_en           <= 1'd0;
        ram_wr_data         <= 10'd0;
    end
    else begin                                  //pix_vaild为低的时候将ram_wr_en拉低
        lint_2bit_cnt       <= lint_2bit_cnt;
        lint_2bit_cnt_reg   <= lint_2bit_cnt_reg;
        block_2bit_cnt      <= block_2bit_cnt;
        block_4bit_cnt      <= block_4bit_cnt;
        block_6bit_cnt      <= block_6bit_cnt;
        block_8bit_cnt      <= block_8bit_cnt;
        ram_wr_addr         <= ram_wr_addr;
        ram_wr_addr_reg     <= ram_wr_addr_reg;
        ram_wr_en           <= 1'd0;
        ram_wr_data         <= ram_wr_data;
    end
  end
/******************* 储存四个bit范围块的信息 ***************************/
wire  [11:0] ram_wr_data_combine;    
assign  ram_wr_data_combine = {bit_flag_d0,ram_wr_data};   //将块的长度和块数据范围信号一并存入ram
wire  [10:0] ram_rd_addr;
// reg  [11:0] ram_rd_data;
wire  [11:0] ram_rd_data;
block_parameter_storage block_parameter_storage(
    // Inputs
    .R_ADDR(ram_rd_addr),   // [10:0]
    .R_CLK(sensor_clk_x4), 
    .W_ADDR(ram_wr_addr),   // [10:0]
    .W_CLK(clk),
    .W_DATA(ram_wr_data_combine),   //[11:0]
    .W_EN(ram_wr_en),    
    // Outputs
    .R_DATA(ram_rd_data)    //[11:0]
);
//**************************** 在一行的数据数据存入fifo以及块信息存入ram之后，根据ram中的块信息对每个数据块进行读出 ****************************//
//**************************** 因为后续要将每个像素都以2bit为单位存入后续fifo，所以模块内部计算好了每个像素保持的时间 ****************************//
//**************************** 8bit的像素要保持四个时钟周期，分为4个bit存取后续fifo （data_rd[7:0] ==>  {data_rd[7:6],data_rd[5:4],data_rd[3:2],data_rd[1:0]}）****************************//
wire fifo_rd_en;
wire   [2:0]   data_bit_cnt;
wire   [9:0]   block_data_cnt;
wire   pulse_en;    //数据块有效的指示信号
read_pulse#(
    .DATA_WIDTH(DATA_WIDTH), 
    .LINE_WIDTH(LINE_WIDTH), 
    .PIX_WIDTH (PIX_WIDTH), 
    .TAPS      (TAPS)    
)read_pulse(
    .clk(clk),//input                            
    .sensor_clk_x4(sensor_clk_x4),//input                            
    .LINE(LINE),   //行数//input       [LINE_WIDTH-1:0]     
    .PIX(PIX),    //每行的像素数//input       [PIX_WIDTH-1:0]      
    .reset(reset),//input                            
    .newframe(newframe),//input                            
    
    .ram_rd_data(ram_rd_data),//input   [11:0]      
    .data_valid(data_valid),//input               
    .ram_wr_addr_reg(ram_wr_addr_reg),//input [10:0]  
    .fifo_data_rd(data_rd),    //input [7:0]           
    .fifo_rd_en_d(rd_en),//output  reg
    .fifo_rd_en(fifo_rd_en),
    .data_bit_cnt(data_bit_cnt),//[2:0]
    .pulse_en(pulse_en),
    .block_data_cnt(block_data_cnt),//[9:0]
   
    .ram_rd_addr(ram_rd_addr)//output  reg [10:0]  

);

//*************************** 根据read_pulse模块读出的数据块前插入块信息，并把每个像素都以2bit存入fifo****************************//
insert_block_information#(
    .DATA_WIDTH (DATA_WIDTH),//        = 14,
    .LINE_WIDTH (LINE_WIDTH),//        = 12,
    .PIX_WIDTH  (PIX_WIDTH),//        = 12,
    .TAPS       (TAPS)//        = 4
)
insert_block_information(
    .clk(clk),//input                            
    .sensor_clk_x4(sensor_clk_x4),//input                            
    .LINE (LINE),   //行数//input       [LINE_WIDTH-1:0]     
    .PIX(PIX) ,    //每行的像素数//input       [PIX_WIDTH-1:0]      
    .reset(reset),//input                            
    .newframe(newframe),//input                            
          //                                 
    .ram_rd_data(ram_rd_data),//input   [11:0]                   
    .data_valid(data_valid),//input                            
    .ram_wr_addr_reg(ram_wr_addr_reg),//input   [10:0]    
    .ram_wr_addr(ram_wr_addr),//input   [10:0]    
    .fifo_rd_en(fifo_rd_en),//input                            
    .fifo_data_rd(data_rd),//input   [7:0]                    
    .ram_rd_addr(ram_rd_addr),//input   [10:0]                   
    .block_data_cnt(block_data_cnt),//input   [9:0]                    
    .data_bit_cnt(data_bit_cnt),//input   [2:0]   
    .pulse_en(pulse_en),   
    .fifo_insert_done_all(fifo_insert_done_all),  
    .frequency_rd_flag  (frequency_rd_flag),          
       //  
    .fifo_insert_done(fifo_insert_done), //output  reg                           
    .data_out(data_out),//output  reg [7:0]               
    .data_lv(data_out_valid)//output  reg                      

);
endmodule