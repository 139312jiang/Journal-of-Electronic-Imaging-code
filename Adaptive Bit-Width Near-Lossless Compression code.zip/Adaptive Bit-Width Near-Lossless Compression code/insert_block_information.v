module insert_block_information#(
    parameter DATA_WIDTH         = 14,
    parameter LINE_WIDTH         = 12,
    parameter PIX_WIDTH          = 12,
    parameter TAPS               = 4
)
(
    input                            clk,
    input                            sensor_clk_x4,
    input       [LINE_WIDTH-1:0]     LINE ,   //行数
    input       [PIX_WIDTH-1:0]      PIX ,    //每行的像素数
    input                            reset,
    input                            newframe,
    
    input   [11:0]      ram_rd_data,
    input               data_valid,
    input   [10:0]      ram_wr_addr_reg,
    input   [10:0]      ram_wr_addr,
    input               fifo_rd_en,
    input   [7:0]       fifo_data_rd,
    input   [10:0]      ram_rd_addr,
    input   [9:0]       block_data_cnt,
    input   [2:0]       data_bit_cnt,
    input               pulse_en,
    input               fifo_insert_done_all,
    input               frequency_rd_flag,

    output  reg         fifo_insert_done,
    output  reg [7:0]   data_out,
    output  reg         data_lv

);
reg  data_valid_d1;
reg  data_valid_d2;
reg  data_valid_d3;
reg  data_valid_d4;
reg  data_valid_d5;
reg  data_valid_d6;
reg  data_valid_d7;
reg  data_valid_d8;

reg  fifo_rd_en_d1;
reg  fifo_rd_en_d2;
reg  fifo_rd_en_d3;
reg  fifo_rd_en_d4;
reg  fifo_rd_en_d5;
reg  [2:0] data_bit_cnt_d1;
reg  [2:0] data_bit_cnt_d2;
reg  [2:0] data_bit_cnt_d3;
reg  [2:0] data_bit_cnt_d4;
reg  pulse_en_d1;
reg  pulse_en_d2;
reg  pulse_en_d3;
reg  pulse_en_d4;
// sensor_clk_x4 时钟域下的延时
always@(posedge sensor_clk_x4)begin
    if(reset || newframe)begin
        fifo_rd_en_d1 <= 1'b0;
        fifo_rd_en_d2 <= 1'b0;
        fifo_rd_en_d3 <= 1'b0;
        fifo_rd_en_d4 <= 1'b0;
        fifo_rd_en_d5 <= 1'b0;
        data_bit_cnt_d1 <= 3'd0;
        data_bit_cnt_d2 <= 3'd0;
        data_bit_cnt_d3 <= 3'd0;
        data_bit_cnt_d4 <= 3'd0;
        pulse_en_d1 <= 1'b0;
        pulse_en_d2 <= 1'b0;
        pulse_en_d3 <= 1'b0;
        pulse_en_d4 <= 1'b0;
        data_valid_d1 <= 1'b0;
        data_valid_d2 <= 1'b0;
        data_valid_d3 <= 1'b0;
        data_valid_d4 <= 1'b0;
        data_valid_d5 <= 1'b0;
        data_valid_d6 <= 1'b0;
        data_valid_d7 <= 1'b0;
        data_valid_d8 <= 1'b0;
    end
    else begin
        fifo_rd_en_d1 <= fifo_rd_en;
        fifo_rd_en_d2 <= fifo_rd_en_d1;
        fifo_rd_en_d3 <= fifo_rd_en_d2;
        fifo_rd_en_d4 <= fifo_rd_en_d3;
        fifo_rd_en_d5 <= fifo_rd_en_d4;
        data_bit_cnt_d1 <= data_bit_cnt;
        data_bit_cnt_d2 <= data_bit_cnt_d1;
        data_bit_cnt_d3 <= data_bit_cnt_d2;
        data_bit_cnt_d4 <= data_bit_cnt_d3;
        pulse_en_d1 <= pulse_en;
        pulse_en_d2 <= pulse_en_d1;
        pulse_en_d3 <= pulse_en_d2;
        pulse_en_d4 <= pulse_en_d3;
        data_valid_d1 <= data_valid;
        data_valid_d2 <= data_valid_d1;
        data_valid_d3 <= data_valid_d2;
        data_valid_d4 <= data_valid_d3;
        data_valid_d5 <= data_valid_d4;
        data_valid_d6 <= data_valid_d5;
        data_valid_d7 <= data_valid_d6;
        data_valid_d8 <= data_valid_d7;
    end
  end

reg  [1:0] insert_bit;    //在4bit块、6bit块、8bit块前插入的块指示信息  
reg   insert_bit_valid;                                                     
always@(posedge sensor_clk_x4)begin
    if(reset || newframe)begin
        insert_bit <= 2'd0;
        insert_bit_valid <= 1'b0;
    end
    else if((fifo_rd_en && !fifo_rd_en_d1) && (block_data_cnt == 10'd0))begin    //插入bit范围指示信号
        if(ram_rd_data[11:10] == 2'd0)begin   //2bit
            insert_bit <= 2'd0;
            insert_bit_valid <= 1'b0;
        end
        else if(ram_rd_data[11:10] == 2'd1)begin   //4bit
            insert_bit <= 2'b01;
            insert_bit_valid <= 1'b1;
        end
        else if(ram_rd_data[11:10] == 2'd2)begin   //6bit
            insert_bit <= 2'b10;
            insert_bit_valid <= 1'b1;
        end
        else if(ram_rd_data[11:10] == 2'd3)begin   //8bit
            insert_bit <= 2'b11;
            insert_bit_valid <= 1'b1;
        end
    end
    else if((fifo_rd_en_d1 && !fifo_rd_en_d2) && (block_data_cnt == 10'd0))begin  //插入块数量信号
        if(ram_rd_data[11:10] == 2'd0)begin   //2bit
            insert_bit <= 2'd0;
            insert_bit_valid <= 1'b0;
        end
        else begin
            insert_bit <= ram_rd_data[1:0];
            insert_bit_valid <= 1'b1;        
        end
    end
    else begin
        insert_bit <= 2'd0;
        insert_bit_valid <= 1'b0;
    end     
end
reg [1:0]  fif0_wr_data;
reg        fif0_wr_en;
reg [9:0]  ram_wr_addr_h2bit;
always@(posedge sensor_clk_x4)begin
    if(reset || newframe)begin
        fif0_wr_data <= 2'b00;
        fif0_wr_en <= 1'b0;
        ram_wr_addr_h2bit <= 10'd0;
    end
    // else if(!data_valid_d1 && data_valid_d2)begin   //插入每行数据块的总数量
    //     fif0_wr_data <= 2'b11;
    //     ram_wr_addr_h2bit <= ram_wr_addr;
    //     fif0_wr_en <= 1'b1;
    // end
    // else if(!data_valid_d2 && data_valid_d3)begin   //插入每行数据块的总数量
    //     fif0_wr_data <= 2'b11;
    //     ram_wr_addr_h2bit <= ram_wr_addr;
    //     fif0_wr_en <= 1'b1;
    // end
    else if(!data_valid_d3 && data_valid_d4)begin   //插入每行数据块的总数量
        fif0_wr_data <= ram_wr_addr[9:8];
        ram_wr_addr_h2bit <= ram_wr_addr;
        fif0_wr_en <= 1'b1;
    end
    else if(!data_valid_d4 && data_valid_d5)begin   //插入每行数据块的总数量
        fif0_wr_data <= ram_wr_addr_reg[7:6];
        fif0_wr_en <= 1'b1;
    end
    else if(!data_valid_d5 && data_valid_d6)begin   //插入每行数据块的总数量
        fif0_wr_data <= ram_wr_addr_reg[5:4];
        fif0_wr_en <= 1'b1;
    end
    else if(!data_valid_d6 && data_valid_d7)begin   //插入每行数据块的总数量
        fif0_wr_data <= ram_wr_addr_reg[3:2];
        fif0_wr_en <= 1'b1;
    end
    else if(!data_valid_d7 && data_valid_d8)begin   //插入每行数据块的总数量
        fif0_wr_data <= ram_wr_addr_reg[1:0];
        fif0_wr_en <= 1'b1;
    end
    else if(insert_bit_valid)begin
        fif0_wr_data <= insert_bit;
        fif0_wr_en <= 1'b1;
    end
    else if(pulse_en_d3)begin
        if(data_bit_cnt_d3 == 3'd0)begin
            fif0_wr_data <= fifo_data_rd[7:6];    
            fif0_wr_en <= 1'b1;
        end
        else if(data_bit_cnt_d3 == 3'd1)begin     //4bit执行到这里
            fif0_wr_data <= fifo_data_rd[5:4];    
            fif0_wr_en <= 1'b1;
        end
        else if(data_bit_cnt_d3 == 3'd2)begin     //6bit执行到这里
            fif0_wr_data <= fifo_data_rd[3:2];    
            fif0_wr_en <= 1'b1;
        end
        else if(data_bit_cnt_d3 == 3'd3)begin     //8bit执行到这里
            fif0_wr_data <= fifo_data_rd[1:0];    
            fif0_wr_en <= 1'b1;
        end
        else begin
            fif0_wr_data <= fif0_wr_data;    
            fif0_wr_en <= fif0_wr_en;
        end       
    end
    else begin
        fif0_wr_data <= 2'd0;
        fif0_wr_en <= 1'b0; 
    end
end
wire  [12:0] RDCNT;
reg  fifo_insert_rd_en;
wire  [7:0] fifo_rd_data;
wire  EMPTY;
//******************** 最后植入指示信号的2bit数据流存入fifo中 **************************//
data_insert_fifo data_insert_fifo(
    // Inputs
    .DATA       (fif0_wr_data),   // [1:0]
    .RCLOCK     (sensor_clk_x4),
    .RE         (fifo_insert_rd_en),
    .RRESET_N   (!newframe ),//(!(data_valid && !data_valid_d1)),//
    .WCLOCK     (sensor_clk_x4),
    .WE         (fif0_wr_en || fif0_wr_en_monitor),
    .WRESET_N   (!newframe ),//(!(data_valid && !data_valid_d1)),//
    // Outputs
    .EMPTY      (EMPTY),
    .FULL       (),
    .Q          (fifo_rd_data),// [1:0]
    .RDCNT      (RDCNT) //[12:0]
);
reg  fif0_wr_en_monitor;
reg  [3:0] monitor_cnt;
reg  [3:0] wr_en_cnt;
//************ 解决以2bit写入fifo，以8bit读出，写入的bit数不是8bit的倍数
always@(posedge sensor_clk_x4)begin
    if(reset || newframe)
        monitor_cnt        <= 4'd4;
    else if(data_valid_d1 && !data_valid)
        monitor_cnt        <= 4'd4;
    else if(fif0_wr_en)begin
        if(monitor_cnt == 4'd0)
            monitor_cnt <= 4'd3;
        else
            monitor_cnt <= monitor_cnt - 4'd1;
    end
    else
        monitor_cnt  <= monitor_cnt;
end

always@(posedge sensor_clk_x4)begin
    if(reset || newframe)begin
        fif0_wr_en_monitor  <= 4'd0;
        wr_en_cnt           <= 4'd0;
    end
    else if(data_valid_d1 && !data_valid)begin
        fif0_wr_en_monitor  <= 4'd0; 
        wr_en_cnt           <= 4'd0;   
    end
    else if(fifo_insert_rd_en)begin   
        if(monitor_cnt == wr_en_cnt)begin
            fif0_wr_en_monitor  <= 4'd0;    
            wr_en_cnt           <= wr_en_cnt;     
        end
        else begin
            fif0_wr_en_monitor  <= 4'd1;    
            wr_en_cnt           <= wr_en_cnt + 4'd1;   
        end
    end
    else begin
        fif0_wr_en_monitor  <= fif0_wr_en_monitor; 
        wr_en_cnt           <= wr_en_cnt         ;      
    end
end

always@(posedge sensor_clk_x4)begin
    if(reset || newframe)
        fifo_insert_rd_en <= 1'b0;
    // else if(ram_wr_addr_reg == ram_rd_addr)
    else if(frequency_rd_flag && !frequency_rd_flag_d)
        fifo_insert_rd_en <= 1'b1;
    else if(RDCNT == 13'd0)
    // else if(EMPTY)
    // else if(EMPTY_d)
        fifo_insert_rd_en <= 1'b0;
    else
        fifo_insert_rd_en <= fifo_insert_rd_en;
end

always@(posedge sensor_clk_x4)begin
    if(reset || newframe)
        fifo_insert_done <= 1'b0;
    else if((ram_wr_addr_reg == ram_rd_addr) && (ram_wr_addr_reg != 11'd0))
        fifo_insert_done <= 1'b1;
    else if(fifo_insert_done_all)
        fifo_insert_done <= 1'b0;
    else
        fifo_insert_done <= fifo_insert_done;
end

reg EMPTY_d;
reg frequency_rd_flag_d;
reg  fifo_insert_rd_en_d0;
reg  fifo_insert_rd_en_d1;

always@(posedge sensor_clk_x4)begin
    EMPTY_d <= EMPTY;    
    frequency_rd_flag_d <= frequency_rd_flag;    
    fifo_insert_rd_en_d0 <= fifo_insert_rd_en;
    fifo_insert_rd_en_d1 <= fifo_insert_rd_en_d0;

    data_out <= {fifo_rd_data[1:0],fifo_rd_data[3:2],fifo_rd_data[5:4],fifo_rd_data[7:6]};//fifo_rd_data;//
    data_lv  <= fifo_insert_rd_en_d0 && fifo_insert_rd_en_d1;

end

endmodule