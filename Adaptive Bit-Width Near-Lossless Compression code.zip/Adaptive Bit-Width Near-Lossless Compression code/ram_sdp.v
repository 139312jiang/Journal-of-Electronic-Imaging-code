
//////////////////////////////////////////////////////////////////////////////////
module ram_sdp
#(
  parameter ADDR_WIDTH    = 11       ,
  parameter DATA_WIDTH    = 8        ,
  parameter DO_REG        = 0        ,
  parameter DEVICE_FAMILY = "Xilinx"  //, "Xilinx", "Cyclone V", "REGS", "ASIC", default: "FPGA"
)
(
  input                       enwp  ,//enable write port
  input                       wrclk ,
  input  [ADDR_WIDTH - 1 : 0] wraddr,
  input                       wr_en ,
  input  [DATA_WIDTH - 1 : 0] wr_dat,
  input                       enrp  ,//enable read port
  input                       rdclk ,
  input  [ADDR_WIDTH - 1 : 0] rdaddr,
  input                       rd_en ,
  output [DATA_WIDTH - 1 : 0] rd_dat
);

  localparam ADDR_NUM = 1 << ADDR_WIDTH;

  generate

    case(DEVICE_FAMILY)
      "REGS":
      begin

        (* keep="true" *)reg [DATA_WIDTH - 1 : 0] Mem [ADDR_NUM - 1 : 0];
        (* keep="true" *)reg [DATA_WIDTH - 1 : 0] rd_dat_reg;
        reg [DATA_WIDTH - 1 : 0] rd_dat_reg_d1;
        always@(posedge wrclk)
        begin
          if(enwp & wr_en)
            Mem[wraddr] <= wr_dat;
        end

        always@(posedge rdclk)
        begin
          if(enrp & rd_en)
            rd_dat_reg <= Mem[rdaddr];
        end

        always @ (posedge rdclk)
        begin
          rd_dat_reg_d1 <= rd_dat_reg;
        end

        assign rd_dat = (DO_REG==1'b0)? rd_dat_reg: rd_dat_reg_d1;
      end



      default:  //"FPGA", "Xilinx", "Cyclone V"
      begin

        reg [DATA_WIDTH - 1 : 0] Mem [ADDR_NUM - 1 : 0];
        reg [DATA_WIDTH - 1 : 0] rd_dat_reg;
        reg [DATA_WIDTH - 1 : 0] rd_dat_reg_d1;
        always@(posedge wrclk)
        begin
          if(enwp & wr_en)
            Mem[wraddr] <= wr_dat;
        end

        always@(posedge rdclk)
        begin
          if(enrp & rd_en)
            rd_dat_reg <= Mem[rdaddr];
        end

        always @ (posedge rdclk)
        begin
          rd_dat_reg_d1 <= rd_dat_reg;
        end

        assign rd_dat = (DO_REG==1'b0)? rd_dat_reg: rd_dat_reg_d1;

      end

    endcase

  endgenerate


endmodule
