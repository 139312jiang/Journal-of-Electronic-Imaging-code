//********************* 控制fifo读取对应块的数据，并根据块的读取情况实时更新ram的读地址***********************//
module read_pulse#(
    parameter DATA_WIDTH         = 14,
    parameter LINE_WIDTH         = 12,
    parameter PIX_WIDTH          = 12,
    parameter TAPS               = 4
)
(
    input                            clk,
    input                            sensor_clk_x4,
    input       [LINE_WIDTH-1:0]     LINE ,   //行数
    input       [PIX_WIDTH-1:0]      PIX ,    //每行的像素数
    input                            reset,
    input                            newframe,
    
    input   [11:0]  ram_rd_data,
    input           data_valid,
    input   [10:0]    ram_wr_addr_reg,
    input   [7:0]       fifo_data_rd,
    output  reg     fifo_rd_en,
    output  reg     fifo_rd_en_d,
    output  reg   [2:0]   data_bit_cnt,
    output  reg   [9:0]   block_data_cnt,
    output  reg       pulse_en,
    output  reg [10:0]  ram_rd_addr

);

reg   data_valid_x4_d0;
reg   data_valid_x4_d1;
reg   data_valid_x4_d2;
reg   data_valid_x4_d3;
reg   data_valid_x4_d4;
reg   data_valid_x4_d5;
reg   [11:0]  ram_rd_data_d;
// reg     fifo_rd_en;
// sensor_clk_x4 时钟域下的延时
always@(posedge sensor_clk_x4)begin
    if(reset || newframe)begin
        data_valid_x4_d0  <= 1'b0;
        data_valid_x4_d1 <= 1'b0;
        data_valid_x4_d2 <= 1'b0;
        data_valid_x4_d3 <= 1'b0;
        data_valid_x4_d4 <= 1'b0;
        data_valid_x4_d5 <= 1'b0;
        ram_rd_data_d    <= 12'd0;
        fifo_rd_en_d     <= 1'b0;
    end
    else begin
        data_valid_x4_d0  <= data_valid;
        data_valid_x4_d1 <= data_valid_x4_d0;
        data_valid_x4_d2 <= data_valid_x4_d1;
        data_valid_x4_d3 <= data_valid_x4_d2;
        data_valid_x4_d4 <= data_valid_x4_d3;
        data_valid_x4_d5 <= data_valid_x4_d4;
        ram_rd_data_d    <= ram_rd_data;
        fifo_rd_en_d     <= fifo_rd_en;
    end
  end

localparam	s_IDLE				    =	'd0,
			s_FIFO_ED_EN    		=	'd1,
			s_RAM_ADDR_ADD			=	'd2,
			s_FIFO_ED_EN_CNT     	=	'd3,
            s_PLUSE_EN           	=	'd4,
            s_END                   =   'd5,
            s_PLUSE_EN_d           	=	'd6,
			s_LD_IDELAY_FINAL	    =	'd11;
reg[3:0]  fsm_process;
// reg       pulse_en;   //ram数据有效输出指示信号，可以发送 freq_convert_fifo 的 fifo_rd_en 信号
// reg       fifo_rd_en;
reg   [11:0]   fifo_rd_en_cnt;  //根据 ram_rd_data 中的块信息来对 fifo_rd_en 的长度进行判定，绝对读取多少次 freq_convert_fifo
// reg   [2:0]   data_bit_cnt;     //根据数据范围，以 2bit 为单位来记录是否读完一个fifo数据
// reg   [9:0]   block_data_cnt;   //记录此时读到数据块的第几个数据

always@(posedge sensor_clk_x4)begin
    if(reset || newframe)begin
        fsm_process     <= s_IDLE;
        pulse_en        <= 1'b0;   
        fifo_rd_en      <= 1'b0;
        fifo_rd_en_cnt  <= 12'd0;
        ram_rd_addr     <= 11'd0;
        data_bit_cnt    <= 3'd0;
        block_data_cnt  <= 10'd0;
    end
    else begin
        case(fsm_process)
            s_IDLE:begin   //'d0
                if(data_valid_x4_d4 && !data_valid_x4_d3)begin
                    ram_rd_addr  <= ram_rd_addr + 1'b1;
                    fsm_process  <= s_PLUSE_EN;
                end
                else begin
                    ram_rd_addr  <= 11'd0;
                    fsm_process  <= s_IDLE;
                end  
            end			
            s_FIFO_ED_EN:begin//'d1
                // if()
                fifo_rd_en <= 1'b1;
                fsm_process  <= s_FIFO_ED_EN_CNT;
            end
            s_RAM_ADDR_ADD:begin//'d2
                if (ram_rd_addr >= ram_wr_addr_reg) begin
                    ram_rd_addr  <= 11'd0;
                    fsm_process  <= s_IDLE;     
                end
                else begin
                    ram_rd_addr  <= ram_rd_addr + 1'b1;
                    fsm_process  <= s_PLUSE_EN;                    
                end
            end 
            s_FIFO_ED_EN_CNT:begin//'d3
                // pulse_en    <= 1'b0;
                fifo_rd_en  <= 1'b0;
                if(ram_rd_data_d[11:10] == 2'b00)begin   //2bit的数据块
                    if(block_data_cnt == (ram_rd_data_d[9:0] - 1'b1))begin
                        if(data_bit_cnt >= 3'd0)begin
                            data_bit_cnt  <= 3'd0;
                            block_data_cnt <= 10'd0;
                            pulse_en    <= 1'b0;
                            fsm_process  <= s_RAM_ADDR_ADD;
                        end      
                        else begin
                            data_bit_cnt  <= data_bit_cnt + 1'b1;
                            block_data_cnt <= block_data_cnt;
                        end                                        
                    end
                    else begin
                        if(data_bit_cnt >= 3'd0)begin
                            data_bit_cnt  <= 3'd0;
                            block_data_cnt <= block_data_cnt + 1'b1;
                            // fsm_process  <= s_FIFO_ED_EN;
                            fifo_rd_en <= 1'b1;
                            // pulse_en    <= 1'b1;
                        end      
                        else begin
                            data_bit_cnt  <= data_bit_cnt + 1'b1;
                            block_data_cnt <= block_data_cnt;
                        end     
                    end        
                end
                else if(ram_rd_data_d[11:10] == 2'b01)begin   //4bit的数据块      数据长度*2
                    if(block_data_cnt == (ram_rd_data_d[9:0] - 1'b1))begin
                        if(data_bit_cnt >= 3'd1)begin
                            data_bit_cnt  <= 3'd0;
                            pulse_en    <= 1'b0;
                            block_data_cnt <= 10'd0;
                            fsm_process  <= s_RAM_ADDR_ADD;
                        end      
                        else begin
                            data_bit_cnt  <= data_bit_cnt + 1'b1;
                            block_data_cnt <= block_data_cnt;
                        end                                        
                    end
                    else begin
                        if(data_bit_cnt >= 3'd1)begin
                            data_bit_cnt  <= 3'd0;
                            // pulse_en    <= 1'b0;
                            block_data_cnt <= block_data_cnt + 1'b1;
                            // fsm_process  <= s_FIFO_ED_EN;
                            fifo_rd_en <= 1'b1;
                        end      
                        else begin
                            data_bit_cnt  <= data_bit_cnt + 1'b1;
                            block_data_cnt <= block_data_cnt;
                        end     
                    end      
                end
                else if(ram_rd_data_d[11:10] == 2'b10)begin   //6bit的数据块      数据长度*3
                    if(block_data_cnt == (ram_rd_data_d[9:0] - 1'b1))begin
                        if(data_bit_cnt >= 3'd2)begin
                            data_bit_cnt  <= 3'd0;
                            pulse_en    <= 1'b0;
                            block_data_cnt <= 10'd0;
                            fsm_process  <= s_RAM_ADDR_ADD;
                        end      
                        else begin
                            data_bit_cnt  <= data_bit_cnt + 1'b1;
                            block_data_cnt <= block_data_cnt;
                        end                                        
                    end
                    else begin
                        if(data_bit_cnt >= 3'd2)begin
                            data_bit_cnt  <= 3'd0;
                            // pulse_en    <= 1'b0;
                            block_data_cnt <= block_data_cnt + 1'b1;
                            // fsm_process  <= s_FIFO_ED_EN;
                            fifo_rd_en <= 1'b1;
                        end      
                        else begin
                            data_bit_cnt  <= data_bit_cnt + 1'b1;
                            block_data_cnt <= block_data_cnt;
                        end     
                    end      
                end
                else if(ram_rd_data_d[11:10] == 2'b11)begin   //8bit的数据块      数据长度*4
                    if(block_data_cnt == (ram_rd_data_d[9:0] - 1'b1))begin
                        if(data_bit_cnt >= 3'd3)begin
                            data_bit_cnt  <= 3'd0;
                            pulse_en    <= 1'b0;
                            block_data_cnt <= 10'd0;
                            fsm_process  <= s_RAM_ADDR_ADD;
                        end      
                        else begin
                            data_bit_cnt  <= data_bit_cnt + 1'b1;
                            block_data_cnt <= block_data_cnt;
                        end                                        
                    end
                    else begin
                        if(data_bit_cnt >= 3'd3)begin
                            data_bit_cnt  <= 3'd0;
                            // pulse_en    <= 1'b0;
                            block_data_cnt <= block_data_cnt + 1'b1;
                            // fsm_process  <= s_FIFO_ED_EN;
                            fifo_rd_en <= 1'b1;
                        end      
                        else begin
                            data_bit_cnt  <= data_bit_cnt + 1'b1;
                            block_data_cnt <= block_data_cnt;
                        end     
                    end      
                end
            end

            s_PLUSE_EN:begin//'d4
                // pulse_en    <= 1'b1;
                // fifo_rd_en  <= 1'b1;
                fsm_process <= s_PLUSE_EN_d;
            end
            s_PLUSE_EN_d:begin//'d4
                pulse_en    <= 1'b1;
                fifo_rd_en  <= 1'b1;
                fsm_process <= s_FIFO_ED_EN_CNT;
            end
            s_END:begin//'d5

            end
            default: begin 
                fsm_process <= s_IDLE; 
            end
        endcase
    end
end









endmodule