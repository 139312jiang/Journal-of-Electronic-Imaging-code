//////////////////////////////////////////////////////////////////////////////////
// Company:        Hikvision Co.,LTC
// Engineer:       Johnson
// Create Date:    2016/11/11 16:37:03  
// Module Name:    two_line_bufs  
// Target Devices: Altera FPGA
// Tool versions: 
// Description:    ���л��棬��Ч���ݴ���һ�е���ʱ(�ض�����ͨ��������谴
//                 �����)
// Dependencies: 

//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module two_line_bufs #(
	parameter DW  = 12 ,
  parameter LW  = 10 ,
	parameter DEPTH = 9 ,
	parameter DEVICE_FAMILY   = "Xilinx"  // else "Xilinx"
)
(
  input                  clk,
  input                  rst,
  input                  v_sync,
  input        [LW-1:0]  v_size,
  input        [DW-1:0]  data_in,
  input                  data_in_valid,
  output  reg  [DW-1:0]  line_buf_out1,
  output       [DW-1:0]  line_buf_out2,
  output  reg            line_buf_valid
  );

  localparam     LAST_LINE_DELAY = 9'd256;

  reg            one_line_rdy;
  reg  [15:0]    line_cnt;
  reg  [8:0]     delay_cnt;
  reg            data_in_valid_d1;
  reg            rd_en;
  reg  [DW-1:0]  data_in_d1;
  wire           fifo_rst;
  wire           empty;
  
  always@(posedge clk,posedge rst)
  begin
  	if(rst)begin
  		one_line_rdy <= 1'b0;
  	end
  	else if(v_sync)begin
  		one_line_rdy <= 1'b0;
  	end
  	else if(data_in_valid_d1 && !data_in_valid)begin
  		one_line_rdy <= 1'b1;
  	end
  	else begin
  		one_line_rdy <= one_line_rdy;
  	end
  end

  always@(posedge clk,posedge rst)
  begin
  	if(rst)begin
  		line_cnt <= 12'b0;
  	end
  	else if(v_sync)begin
  		line_cnt <= 12'b0;
  	end
  	else if(data_in_valid_d1 && !data_in_valid)begin
  		line_cnt <= line_cnt + 1'b1;
  	end
  	else begin
  		line_cnt <= line_cnt;
  	end
  end


  always@(posedge clk,posedge rst)
  begin
  	if(rst)begin
  		delay_cnt <= 4'b0;
  	end
  	else if(v_sync)begin
  		delay_cnt <= 4'b0;
  	end
  	else if(line_cnt==v_size && delay_cnt!=LAST_LINE_DELAY)begin
  		delay_cnt <= delay_cnt + 1'b1;
  	end
  	else begin
  		delay_cnt <= delay_cnt;
  	end
  end

  always@(posedge clk,posedge rst)
  begin
  	if(rst)begin
  		rd_en <= 1'b0;
  	end
  	else if((one_line_rdy && data_in_valid) ||
  	       (delay_cnt==LAST_LINE_DELAY && !empty))begin
  		rd_en <= 1'b1;
  	end
  	else begin
  		rd_en <= 1'b0;
  	end
  end

  always@(posedge clk,posedge rst)
  begin
  	if(rst)begin
  		line_buf_valid <= 1'b0;
  	end
  	else if(!empty && rd_en)begin
  		line_buf_valid <= 1'b1;
  	end
  	else begin
  		line_buf_valid <= 1'b0;
  	end
  end

  assign fifo_rst = rst||v_sync;
/*  
  sync_fifo_top #(
  	.DATA_PORT_SIZE(DW), 
  	.COUNT_PORT_SIZE(DEPTH),
  	.DEVICE_FAMILY(DEVICE_FAMILY) 
  )
  line_buf2(
  	.clk     ( clk            ),
  	.rst     ( fifo_rst       ),
  	.din     ( data_in        ),
  	.wr_en   ( data_in_valid  ),
  	.rd_en   ( rd_en          ),
  	.dout    ( line_buf_out2  ),
  	.full    (                ),
  	.empty   ( empty          ),
  	.valid   (                )
  );
*/
async_fifo_top #(
  .DATA_WIDTH    		(DW        ),
  .ADDR_WIDTH    		(DEPTH        ),
  .COUNT_PORT    		("DISABLE" ),  // "DISABLE","ENABLE"
  .FIFO_FWFT     		("FALSE"   ),  // "FALSE", "TRUE"
  .DEVICE_FAMILY 		("Xilinx"    )   //"Xilinx", "Cyclone V", "REGS", "ASIC"
)
async_fifo_top_1(
  .arst    				(	fifo_rst),
  .wclk    				(	clk	),
  .wren    				(	data_in_valid	),
  .din     				(	data_in	),
  .rclk    				(	clk	),
  .rden    				(	rd_en	),
  .dout    				(	line_buf_out2	),
  .wr_count				(		),//wr clk fifo count
  .rd_count				(		),//rd clk fifo count
  .empty   				(	empty	),
  .full    				(		)
);

  always@(posedge clk)
  begin
    data_in_d1 <= data_in;
    line_buf_out1 <= data_in_d1;
  end

  always@(posedge clk,posedge rst)
  begin
  	if(rst)begin
  		data_in_valid_d1 <= 1'b0;
  	end
  	else begin
  		data_in_valid_d1 <= data_in_valid;
  	end
  end


endmodule
